﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RotorInterface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RotorInterface))
        Me.MainLnkBtn = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Rotor3CurPos = New System.Windows.Forms.Label()
        Me.Rotor3LasPos = New System.Windows.Forms.Label()
        Me.Rotor3NexPos = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Rotor2CurPos = New System.Windows.Forms.Label()
        Me.Rotor2LasPos = New System.Windows.Forms.Label()
        Me.Rotor2NexPos = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Rotor1CurPos = New System.Windows.Forms.Label()
        Me.Rotor1LasPos = New System.Windows.Forms.Label()
        Me.Rotor1NexPos = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.HelpBtn = New System.Windows.Forms.PictureBox()
        Me.Rotor2DskComBox = New System.Windows.Forms.ComboBox()
        Me.Rotor3DskComBox = New System.Windows.Forms.ComboBox()
        Me.Rotor1DskComBox = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SaveChangesBtn = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.HelpBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainLnkBtn
        '
        Me.MainLnkBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainLnkBtn.Location = New System.Drawing.Point(12, 13)
        Me.MainLnkBtn.Name = "MainLnkBtn"
        Me.MainLnkBtn.Size = New System.Drawing.Size(75, 27)
        Me.MainLnkBtn.TabIndex = 1
        Me.MainLnkBtn.Text = "Main"
        Me.MainLnkBtn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.MainLnkBtn.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(68, 160)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 19)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "<-- Current Position"
        '
        'Rotor3CurPos
        '
        Me.Rotor3CurPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor3CurPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor3CurPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor3CurPos.Location = New System.Drawing.Point(29, 152)
        Me.Rotor3CurPos.Name = "Rotor3CurPos"
        Me.Rotor3CurPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor3CurPos.TabIndex = 20
        Me.Rotor3CurPos.Text = "B"
        Me.Rotor3CurPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor3CurPos, "Rotor 3's current position")
        '
        'Rotor3LasPos
        '
        Me.Rotor3LasPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor3LasPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor3LasPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor3LasPos.Location = New System.Drawing.Point(29, 117)
        Me.Rotor3LasPos.Name = "Rotor3LasPos"
        Me.Rotor3LasPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor3LasPos.TabIndex = 19
        Me.Rotor3LasPos.Text = "A"
        Me.Rotor3LasPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor3LasPos, "Click here to decrease this rotor's position")
        '
        'Rotor3NexPos
        '
        Me.Rotor3NexPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor3NexPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor3NexPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor3NexPos.Location = New System.Drawing.Point(29, 188)
        Me.Rotor3NexPos.Name = "Rotor3NexPos"
        Me.Rotor3NexPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor3NexPos.TabIndex = 18
        Me.Rotor3NexPos.Text = "C"
        Me.Rotor3NexPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor3NexPos, "Click here to increase this rotor's position")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(249, 160)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 19)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "<-- Current Position"
        '
        'Rotor2CurPos
        '
        Me.Rotor2CurPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor2CurPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor2CurPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor2CurPos.Location = New System.Drawing.Point(210, 152)
        Me.Rotor2CurPos.Name = "Rotor2CurPos"
        Me.Rotor2CurPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor2CurPos.TabIndex = 24
        Me.Rotor2CurPos.Text = "B"
        Me.Rotor2CurPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor2CurPos, "Rotor 2's current position")
        '
        'Rotor2LasPos
        '
        Me.Rotor2LasPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor2LasPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor2LasPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor2LasPos.Location = New System.Drawing.Point(210, 117)
        Me.Rotor2LasPos.Name = "Rotor2LasPos"
        Me.Rotor2LasPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor2LasPos.TabIndex = 23
        Me.Rotor2LasPos.Text = "A"
        Me.Rotor2LasPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor2LasPos, "Click here to decrease this rotor's position")
        '
        'Rotor2NexPos
        '
        Me.Rotor2NexPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor2NexPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor2NexPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor2NexPos.Location = New System.Drawing.Point(210, 188)
        Me.Rotor2NexPos.Name = "Rotor2NexPos"
        Me.Rotor2NexPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor2NexPos.TabIndex = 22
        Me.Rotor2NexPos.Text = "C"
        Me.Rotor2NexPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor2NexPos, "Click here to increase this rotor's position")
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(429, 160)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(132, 19)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "<-- Current Position"
        '
        'Rotor1CurPos
        '
        Me.Rotor1CurPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor1CurPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor1CurPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor1CurPos.Location = New System.Drawing.Point(390, 152)
        Me.Rotor1CurPos.Name = "Rotor1CurPos"
        Me.Rotor1CurPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor1CurPos.TabIndex = 28
        Me.Rotor1CurPos.Text = "B"
        Me.Rotor1CurPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor1CurPos, "Rotor 1's current position")
        '
        'Rotor1LasPos
        '
        Me.Rotor1LasPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor1LasPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor1LasPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor1LasPos.Location = New System.Drawing.Point(390, 117)
        Me.Rotor1LasPos.Name = "Rotor1LasPos"
        Me.Rotor1LasPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor1LasPos.TabIndex = 27
        Me.Rotor1LasPos.Text = "A"
        Me.Rotor1LasPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor1LasPos, "Click here to decrease this rotor's position")
        '
        'Rotor1NexPos
        '
        Me.Rotor1NexPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor1NexPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor1NexPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor1NexPos.Location = New System.Drawing.Point(390, 188)
        Me.Rotor1NexPos.Name = "Rotor1NexPos"
        Me.Rotor1NexPos.Size = New System.Drawing.Size(33, 36)
        Me.Rotor1NexPos.TabIndex = 26
        Me.Rotor1NexPos.Text = "C"
        Me.Rotor1NexPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor1NexPos, "Click here to increase this rotor's position")
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(26, 66)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 24)
        Me.Label10.TabIndex = 30
        Me.Label10.Text = "Rotor 3"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(206, 66)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(78, 24)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Rotor 2"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(386, 66)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 24)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "Rotor 1"
        '
        'HelpBtn
        '
        Me.HelpBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.HelpBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.HelpBtn.Image = CType(resources.GetObject("HelpBtn.Image"), System.Drawing.Image)
        Me.HelpBtn.Location = New System.Drawing.Point(549, 13)
        Me.HelpBtn.Name = "HelpBtn"
        Me.HelpBtn.Size = New System.Drawing.Size(47, 44)
        Me.HelpBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HelpBtn.TabIndex = 33
        Me.HelpBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.HelpBtn, "Disable tooltips")
        '
        'Rotor2DskComBox
        '
        Me.Rotor2DskComBox.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor2DskComBox.FormattingEnabled = True
        Me.Rotor2DskComBox.Items.AddRange(New Object() {"1", "2", "3", "4", "5"})
        Me.Rotor2DskComBox.Location = New System.Drawing.Point(253, 95)
        Me.Rotor2DskComBox.Name = "Rotor2DskComBox"
        Me.Rotor2DskComBox.Size = New System.Drawing.Size(121, 22)
        Me.Rotor2DskComBox.TabIndex = 35
        Me.ToolTip1.SetToolTip(Me.Rotor2DskComBox, "Change the cypher of rotor 2")
        '
        'Rotor3DskComBox
        '
        Me.Rotor3DskComBox.DisplayMember = "2"
        Me.Rotor3DskComBox.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor3DskComBox.FormattingEnabled = True
        Me.Rotor3DskComBox.Items.AddRange(New Object() {"1", "2", "3", "4", "5"})
        Me.Rotor3DskComBox.Location = New System.Drawing.Point(72, 95)
        Me.Rotor3DskComBox.MaxLength = 1
        Me.Rotor3DskComBox.Name = "Rotor3DskComBox"
        Me.Rotor3DskComBox.Size = New System.Drawing.Size(121, 22)
        Me.Rotor3DskComBox.TabIndex = 36
        Me.ToolTip1.SetToolTip(Me.Rotor3DskComBox, "Change the cypher of rotor 1")
        '
        'Rotor1DskComBox
        '
        Me.Rotor1DskComBox.DisplayMember = "1"
        Me.Rotor1DskComBox.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor1DskComBox.FormattingEnabled = True
        Me.Rotor1DskComBox.Items.AddRange(New Object() {"1", "2", "3", "4", "5"})
        Me.Rotor1DskComBox.Location = New System.Drawing.Point(433, 95)
        Me.Rotor1DskComBox.Name = "Rotor1DskComBox"
        Me.Rotor1DskComBox.Size = New System.Drawing.Size(121, 22)
        Me.Rotor1DskComBox.TabIndex = 37
        Me.ToolTip1.SetToolTip(Me.Rotor1DskComBox, "Change the cypher of rotor 1")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(474, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 28)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Click here -->" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for help."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(175, 18)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(171, 26)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Rotor Interface"
        '
        'SaveChangesBtn
        '
        Me.SaveChangesBtn.Location = New System.Drawing.Point(498, 197)
        Me.SaveChangesBtn.Name = "SaveChangesBtn"
        Me.SaveChangesBtn.Size = New System.Drawing.Size(84, 23)
        Me.SaveChangesBtn.TabIndex = 40
        Me.SaveChangesBtn.Text = "Save Changes"
        Me.SaveChangesBtn.UseVisualStyleBackColor = True
        '
        'RotorInterface
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(608, 243)
        Me.ControlBox = False
        Me.Controls.Add(Me.SaveChangesBtn)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Rotor1DskComBox)
        Me.Controls.Add(Me.Rotor3DskComBox)
        Me.Controls.Add(Me.Rotor2DskComBox)
        Me.Controls.Add(Me.HelpBtn)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Rotor1CurPos)
        Me.Controls.Add(Me.Rotor1LasPos)
        Me.Controls.Add(Me.Rotor1NexPos)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Rotor2CurPos)
        Me.Controls.Add(Me.Rotor2LasPos)
        Me.Controls.Add(Me.Rotor2NexPos)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Rotor3CurPos)
        Me.Controls.Add(Me.Rotor3LasPos)
        Me.Controls.Add(Me.Rotor3NexPos)
        Me.Controls.Add(Me.MainLnkBtn)
        Me.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "RotorInterface"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rotor Interface"
        CType(Me.HelpBtn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MainLnkBtn As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Rotor3CurPos As Label
    Friend WithEvents Rotor3LasPos As Label
    Friend WithEvents Rotor3NexPos As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Rotor2CurPos As Label
    Friend WithEvents Rotor2LasPos As Label
    Friend WithEvents Rotor2NexPos As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Rotor1CurPos As Label
    Friend WithEvents Rotor1LasPos As Label
    Friend WithEvents Rotor1NexPos As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents HelpBtn As PictureBox
    Friend WithEvents Rotor2DskComBox As ComboBox
    Friend WithEvents Rotor3DskComBox As ComboBox
    Friend WithEvents Rotor1DskComBox As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents SaveChangesBtn As Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
