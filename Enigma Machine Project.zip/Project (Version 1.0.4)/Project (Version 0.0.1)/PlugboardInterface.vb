﻿Option Explicit On
Public Class PlugboardInterface

    Dim strTempPlugboard As String = ""
    Dim strLocalPlugboard As String = ""
    Dim blnFirstLoad As Boolean = True
    Dim blnRepaint As Boolean = True


    Private Sub MainLnkBtn_Click(sender As Object, e As EventArgs) Handles MainLnkBtn.Click

        MainInterface.Show()
        Close()

    End Sub

    Private Sub HelpBtn_Click(sender As Object, e As EventArgs) Handles HelpBtn.Click
        Try
            'turn on tooltips, or off if its already on
            If ToolTip1.Active = True Then
                ToolTip1.Active = False
                GlobalVariables.blnHelpCheck = False
                HelpBtn.Image = Image.FromFile("1200px-OOjs_UI_icon_eyeClosed.png")
            Else
                ToolTip1.Active = True
                GlobalVariables.blnHelpCheck = True
                HelpBtn.Image = Image.FromFile("eye-icon-1464.png")
            End If
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub PlugboardInterface_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            blnFirstLoad = True
            blnRepaint = True
            strLocalPlugboard = GlobalVariables.strPlugboard

            'turn on tooltips
            If GlobalVariables.blnHelpCheck = True Then
                ToolTip1.Active = True
                HelpBtn.Image = Image.FromFile("eye-icon-1464.png")
            Else
                ToolTip1.Active = False
                HelpBtn.Image = Image.FromFile("1200px-OOjs_UI_icon_eyeClosed.png")
            End If


            'set text box = global plugboard variable
            ConnectionsTxt.Text = GlobalVariables.strPlugboard
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub SaveChangesBtn_Click(sender As Object, e As EventArgs) Handles SaveChangesBtn.Click
        Try
            'set global variable = text box
            If Len(strLocalPlugboard) <> 1 And Len(strLocalPlugboard) Mod 2 <> 0 Then
                MsgBox("The plugboard is an odd length! Clearing the plugboard.")
                strLocalPlugboard = ""
                Exit Sub
            End If

            GlobalVariables.strPlugboard = strLocalPlugboard
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Sub UpdateConnections(ByVal character As Char)
        Try
            Dim msgResponse As String
            'set as 5 longer than variable length so that if it's not called later it won't interfere
            Dim intIgnPos As Integer = Len(strLocalPlugboard) + 5
            Dim strTempBoard As String = ""

            'If character was already clicked, clear the temp
            If character = strTempPlugboard Then
                strTempPlugboard = ""
                Exit Sub
            End If

            For i = 1 To Len(strLocalPlugboard)
                'checks if chosen character already exists in plugboard
                If character = Mid(strLocalPlugboard, i, 1) Then
                    'asks if it should be removed if found
                    msgResponse = MsgBox("This key is already used by a connection on the plugbard, would you like to remove that connection?", vbYesNo)
                    If msgResponse = vbYes Then
                        'if yes, find if character's position is even or odd
                        If i Mod 2 <> 0 Or i = 1 Then
                            'if even save current pos
                            intIgnPos = i
                        Else
                            'if odd save previus pos
                            intIgnPos = i - 1
                        End If

                        'copy plugboard into temp without the to-be ignored connections
                        For count = 1 To Len(strLocalPlugboard)
                            If count = intIgnPos Then
                                'skip current and next pos
                                count = count + 2
                            End If
                            'copy current character to new temp
                            strTempBoard = strTempBoard + Mid(strLocalPlugboard, count, 1)
                        Next

                        If Len(strTempPlugboard) = 1 Then
                            strTempPlugboard = strTempPlugboard + character
                            strTempBoard = strTempBoard + strTempPlugboard
                        End If

                        PaintForm()

                        strLocalPlugboard = strTempBoard

                        'update connections text
                        ConnectionsTxt.Text = strLocalPlugboard

                        'repaint lines
                        PaintForm()

                        strTempPlugboard = ""
                        Exit Sub
                    Else
                        strTempPlugboard = ""
                        Exit Sub
                    End If
                End If
            Next

            'add character to plugboard
            strTempPlugboard = strTempPlugboard + character

            'if the temperary board is full than add it to the local board and clear the temp
            If Len(strTempPlugboard) = 2 Then
                strLocalPlugboard = strLocalPlugboard + strTempPlugboard
                PaintForm()

                'update connections text
                ConnectionsTxt.Text = strLocalPlugboard
                strTempPlugboard = ""
            End If

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Sub addLines(ByVal char1 As Char, ByVal char2 As Char, ByVal resetLine As Boolean)
        Try
            'declare variables
            Dim intY1, intX1, intY2, intX2 As Integer
            Dim search As Char = ""

            Dim surface As Graphics = CreateGraphics()
            Dim pen1 As Pen = New Pen(Color.Black, 2)

            If resetLine = True Then
                surface.Clear(Color.White)
                resetLine = False
            End If


            'set X1,Y1 and X2,Y2
            'Add ~17 to each x, minus ~17 from each y
            For i = 0 To 1
                If i = 0 Then
                    search = char1
                Else
                    search = char2
                End If
                If search = "/" Then
                    i = i
                ElseIf search = "Q" Then
                    If i = 0 Then
                        intY1 = InputQBtn.Location.Y
                        intX1 = InputQBtn.Location.X
                    Else
                        intY2 = InputQBtn.Location.Y
                        intX2 = InputQBtn.Location.X
                    End If
                ElseIf search = "W" Then
                    If i = 0 Then
                        intY1 = InputWBtn.Location.Y
                        intX1 = InputWBtn.Location.X
                    Else
                        intY2 = InputWBtn.Location.Y
                        intX2 = InputWBtn.Location.X
                    End If
                ElseIf search = "E" Then
                    If i = 0 Then
                        intY1 = InputEBtn.Location.Y
                        intX1 = InputEBtn.Location.X
                    Else
                        intY2 = InputEBtn.Location.Y
                        intX2 = InputEBtn.Location.X
                    End If
                ElseIf search = "R" Then
                    If i = 0 Then
                        intY1 = InputRBtn.Location.Y
                        intX1 = InputRBtn.Location.X
                    Else
                        intY2 = InputRBtn.Location.Y
                        intX2 = InputRBtn.Location.X
                    End If
                ElseIf search = "T" Then
                    If i = 0 Then
                        intY1 = InputTBtn.Location.Y
                        intX1 = InputTBtn.Location.X
                    Else
                        intY2 = InputTBtn.Location.Y
                        intX2 = InputTBtn.Location.X
                    End If
                ElseIf search = "Y" Then
                    If i = 0 Then
                        intY1 = InputYBtn.Location.Y
                        intX1 = InputYBtn.Location.X
                    Else
                        intY2 = InputYBtn.Location.Y
                        intX2 = InputYBtn.Location.X
                    End If
                ElseIf search = "U" Then
                    If i = 0 Then
                        intY1 = InputUBtn.Location.Y
                        intX1 = InputUBtn.Location.X
                    Else
                        intY2 = InputUBtn.Location.Y
                        intX2 = InputUBtn.Location.X
                    End If
                ElseIf search = "I" Then
                    If i = 0 Then
                        intY1 = InputIBtn.Location.Y
                        intX1 = InputIBtn.Location.X
                    Else
                        intY2 = InputIBtn.Location.Y
                        intX2 = InputIBtn.Location.X
                    End If
                ElseIf search = "O" Then
                    If i = 0 Then
                        intY1 = InputOBtn.Location.Y
                        intX1 = InputOBtn.Location.X
                    Else
                        intY2 = InputOBtn.Location.Y
                        intX2 = InputOBtn.Location.X
                    End If
                ElseIf search = "P" Then
                    If i = 0 Then
                        intY1 = InputPBtn.Location.Y
                        intX1 = InputPBtn.Location.X
                    Else
                        intY2 = InputPBtn.Location.Y
                        intX2 = InputPBtn.Location.X
                    End If
                ElseIf search = "A" Then
                    If i = 0 Then
                        intY1 = InputABtn.Location.Y
                        intX1 = InputABtn.Location.X
                    Else
                        intY2 = InputABtn.Location.Y
                        intX2 = InputABtn.Location.X
                    End If
                ElseIf search = "S" Then
                    If i = 0 Then
                        intY1 = InputSBtn.Location.Y
                        intX1 = InputSBtn.Location.X
                    Else
                        intY2 = InputSBtn.Location.Y
                        intX2 = InputSBtn.Location.X
                    End If
                ElseIf search = "D" Then
                    If i = 0 Then
                        intY1 = InputDBtn.Location.Y
                        intX1 = InputDBtn.Location.X
                    Else
                        intY2 = InputDBtn.Location.Y
                        intX2 = InputDBtn.Location.X
                    End If
                ElseIf search = "F" Then
                    If i = 0 Then
                        intY1 = InputFBtn.Location.Y
                        intX1 = InputFBtn.Location.X
                    Else
                        intY2 = InputFBtn.Location.Y
                        intX2 = InputFBtn.Location.X
                    End If
                ElseIf search = "G" Then
                    If i = 0 Then
                        intY1 = InputGBtn.Location.Y
                        intX1 = InputGBtn.Location.X
                    Else
                        intY2 = InputGBtn.Location.Y
                        intX2 = InputGBtn.Location.X
                    End If
                ElseIf search = "H" Then
                    If i = 0 Then
                        intY1 = InputHBtn.Location.Y
                        intX1 = InputHBtn.Location.X
                    Else
                        intY2 = InputHBtn.Location.Y
                        intX2 = InputHBtn.Location.X
                    End If
                ElseIf search = "J" Then
                    If i = 0 Then
                        intY1 = InputJBtn.Location.Y
                        intX1 = InputJBtn.Location.X
                    Else
                        intY2 = InputJBtn.Location.Y
                        intX2 = InputJBtn.Location.X
                    End If
                ElseIf search = "K" Then
                    If i = 0 Then
                        intY1 = InputKBtn.Location.Y
                        intX1 = InputKBtn.Location.X
                    Else
                        intY2 = InputKBtn.Location.Y
                        intX2 = InputKBtn.Location.X
                    End If
                ElseIf search = "L" Then
                    If i = 0 Then
                        intY1 = InputLBtn.Location.Y
                        intX1 = InputLBtn.Location.X
                    Else
                        intY2 = InputLBtn.Location.Y
                        intX2 = InputLBtn.Location.X
                    End If
                ElseIf search = "Z" Then
                    If i = 0 Then
                        intY1 = InputZBtn.Location.Y
                        intX1 = InputZBtn.Location.X
                    Else
                        intY2 = InputZBtn.Location.Y
                        intX2 = InputZBtn.Location.X
                    End If
                ElseIf search = "X" Then
                    If i = 0 Then
                        intY1 = InputXBtn.Location.Y
                        intX1 = InputXBtn.Location.X
                    Else
                        intY2 = InputXBtn.Location.Y
                        intX2 = InputXBtn.Location.X
                    End If
                ElseIf search = "C" Then
                    If i = 0 Then
                        intY1 = InputCBtn.Location.Y
                        intX1 = InputCBtn.Location.X
                    Else
                        intY2 = InputCBtn.Location.Y
                        intX2 = InputCBtn.Location.X
                    End If
                ElseIf search = "V" Then
                    If i = 0 Then
                        intY1 = InputVBtn.Location.Y
                        intX1 = InputVBtn.Location.X
                    Else
                        intY2 = InputVBtn.Location.Y
                        intX2 = InputVBtn.Location.X
                    End If
                ElseIf search = "B" Then
                    If i = 0 Then
                        intY1 = InputBBtn.Location.Y
                        intX1 = InputBBtn.Location.X
                    Else
                        intY2 = InputBBtn.Location.Y
                        intX2 = InputBBtn.Location.X
                    End If
                ElseIf search = "N" Then
                    If i = 0 Then
                        intY1 = InputNBtn.Location.Y
                        intX1 = InputNBtn.Location.X
                    Else
                        intY2 = InputNBtn.Location.Y
                        intX2 = InputNBtn.Location.X
                    End If
                ElseIf search = "M" Then
                    If i = 0 Then
                        intY1 = InputMBtn.Location.Y
                        intX1 = InputMBtn.Location.X
                    Else
                        intY2 = InputMBtn.Location.Y
                        intX2 = InputMBtn.Location.X
                    End If
                End If
            Next

            'draw line between X1,Y1 and X2,Y2
            surface.DrawLine(pen1, (intX1 + 17), (intY1 + 17), (intX2 + 17), (intY2 + 17))




        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputQBtn_Click(sender As Object, e As EventArgs) Handles InputQBtn.Click
        Try
            UpdateConnections("Q")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputWBtn_Click(sender As Object, e As EventArgs) Handles InputWBtn.Click
        Try
            UpdateConnections("W")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputEBtn_Click(sender As Object, e As EventArgs) Handles InputEBtn.Click
        Try
            UpdateConnections("E")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputRBtn_Click(sender As Object, e As EventArgs) Handles InputRBtn.Click
        Try
            UpdateConnections("R")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputTBtn_Click(sender As Object, e As EventArgs) Handles InputTBtn.Click
        Try
            UpdateConnections("T")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputYBtn_Click(sender As Object, e As EventArgs) Handles InputYBtn.Click
        Try
            UpdateConnections("Y")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputUBtn_Click(sender As Object, e As EventArgs) Handles InputUBtn.Click
        Try
            UpdateConnections("U")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputIBtn_Click(sender As Object, e As EventArgs) Handles InputIBtn.Click
        Try
            UpdateConnections("I")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputOBtn_Click(sender As Object, e As EventArgs) Handles InputOBtn.Click
        Try
            UpdateConnections("O")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputPBtn_Click(sender As Object, e As EventArgs) Handles InputPBtn.Click
        Try
            UpdateConnections("P")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputABtn_Click(sender As Object, e As EventArgs) Handles InputABtn.Click
        Try
            UpdateConnections("A")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputSBtn_Click(sender As Object, e As EventArgs) Handles InputSBtn.Click
        Try
            UpdateConnections("S")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputDBtn_Click(sender As Object, e As EventArgs) Handles InputDBtn.Click
        Try
            UpdateConnections("D")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputFBtn_Click(sender As Object, e As EventArgs) Handles InputFBtn.Click
        Try
            UpdateConnections("F")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputGBtn_Click(sender As Object, e As EventArgs) Handles InputGBtn.Click
        Try
            UpdateConnections("G")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputHBtn_Click(sender As Object, e As EventArgs) Handles InputHBtn.Click
        Try
            UpdateConnections("H")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputJBtn_Click(sender As Object, e As EventArgs) Handles InputJBtn.Click
        Try
            UpdateConnections("J")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputKBtn_Click(sender As Object, e As EventArgs) Handles InputKBtn.Click
        Try
            UpdateConnections("K")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputLBtn_Click(sender As Object, e As EventArgs) Handles InputLBtn.Click
        Try
            UpdateConnections("L")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputZBtn_Click(sender As Object, e As EventArgs) Handles InputZBtn.Click
        Try
            UpdateConnections("Z")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputXBtn_Click(sender As Object, e As EventArgs) Handles InputXBtn.Click
        Try
            UpdateConnections("X")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputCBtn_Click(sender As Object, e As EventArgs) Handles InputCBtn.Click
        Try
            UpdateConnections("C")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputVBtn_Click(sender As Object, e As EventArgs) Handles InputVBtn.Click
        Try
            UpdateConnections("V")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputBBtn_Click(sender As Object, e As EventArgs) Handles InputBBtn.Click
        Try
            UpdateConnections("B")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputNBtn_Click(sender As Object, e As EventArgs) Handles InputNBtn.Click
        Try
            UpdateConnections("N")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputMBtn_Click(sender As Object, e As EventArgs) Handles InputMBtn.Click
        Try
            UpdateConnections("M")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub PlugboardInterface_Paint(sender As Object, e As PaintEventArgs) Handles Me.Paint
        Try
            If blnRepaint = True Then
                Call PaintForm()
                blnRepaint = False
            End If
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Sub PaintForm()
        Try
            addLines("/", "/", True)

            Dim char1, char2 As Char


            'call subroutine to add line connections
            For i = 1 To Len(strLocalPlugboard)
                char1 = Mid(strLocalPlugboard, i, 1)
                i = i + 1
                char2 = Mid(strLocalPlugboard, i, 1)

                addLines(char1, char2, False)
            Next

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub
End Class
