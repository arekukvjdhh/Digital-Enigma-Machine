﻿Option Explicit On
Imports System.Net.Mail
Public Class MainInterface

    Private Sub ExitBtn_Click(sender As Object, e As EventArgs) Handles ExitBtn.Click

        'closes form, and thus program as no other forms should be open
        Close()

    End Sub

    Private Sub SetlnkBtn_Click(sender As Object, e As EventArgs) Handles SetlnkBtn.Click

        'save current output text, then open settings form, then close main form
        SettingsInterface.Show()
        GlobalVariables.strOutputBox = OutputTextBox.Text
        Me.Close()

    End Sub

    Private Sub AnallnkBtn_Click(sender As Object, e As EventArgs) Handles AnallnkBtn.Click

        'save current output text, then open Analysis form, then close main form
        AnalysisInterface.Show()
        GlobalVariables.strOutputBox = OutputTextBox.Text
        Me.Close()

    End Sub

    Private Sub RotLnkBtn_Click(sender As Object, e As EventArgs) Handles RotLnkBtn.Click

        'save current output text, then open Rotor form, then close main form
        RotorInterface.Show()
        GlobalVariables.strOutputBox = OutputTextBox.Text
        Close()

    End Sub

    Private Sub PlugLnkBtn_Click(sender As Object, e As EventArgs) Handles PlugLnkBtn.Click

        'save current output text, then open Plugboard form, then close main form
        PlugboardInterface.Show()
        GlobalVariables.strOutputBox = OutputTextBox.Text
        Close()

    End Sub

    Public Sub MainInterface_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            'call subroutine to update global settings, such as rotor positions.
            Call LoadSettings()
            'call subroutine to update rotor display to their current positions
            Call UpdateRotors()

            If GlobalVariables.blnHelpCheck = True Then
                'if the global help variable is true, display tooltips and change the image to an open eye
                ToolTip1.Active = True
                HelpBtn.Image = Image.FromFile("eye-icon-1464.png")
            Else
                'if the global help variable is false, disable tooltips and change the image to a closed eye
                ToolTip1.Active = False
                HelpBtn.Image = Image.FromFile("1200px-OOjs_UI_icon_eyeClosed.png")
            End If

            'set the text in the output box equal to the glabal variable for encrypted text
            OutputTextBox.Text = GlobalVariables.strOutputBox
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub HelpBtn_Click(sender As Object, e As EventArgs) Handles HelpBtn.Click
        Try
            If ToolTip1.Active = True Then
                'if the global help variable is true, set it to false and disable tooltips then change the image to a closed eye
                ToolTip1.Active = False
                GlobalVariables.blnHelpCheck = False
                HelpBtn.Image = Image.FromFile("1200px-OOjs_UI_icon_eyeClosed.png")
            Else
                'if the global help variable is false, set it to true and enable tooltips then change the image to an open eye
                ToolTip1.Active = True
                GlobalVariables.blnHelpCheck = True
                HelpBtn.Image = Image.FromFile("eye-icon-1464.png")
            End If
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try

    End Sub

    Private Sub InputQBtn_Click(sender As Object, e As EventArgs) Handles InputQBtn.Click
        Try
            'update the output text with the letter returned by Q being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("Q", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputWBtn_Click(sender As Object, e As EventArgs) Handles InputWBtn.Click
        Try
            'update the output text with the letter returned by W being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("W", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputEBtn_Click(sender As Object, e As EventArgs) Handles InputEBtn.Click
        Try
            'update the output text with the letter returned by E being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("E", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputRBtn_Click(sender As Object, e As EventArgs) Handles InputRBtn.Click
        Try
            'update the output text with the letter returned by R being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("R", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputTBtn_Click(sender As Object, e As EventArgs) Handles InputTBtn.Click
        Try
            'update the output text with the letter returned by T being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("T", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputYBtn_Click(sender As Object, e As EventArgs) Handles InputYBtn.Click
        Try
            'update the output text with the letter returned by Y being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("Y", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputUBtn_Click(sender As Object, e As EventArgs) Handles InputUBtn.Click
        Try
            'update the output text with the letter returned by U being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("U", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputIBtn_Click(sender As Object, e As EventArgs) Handles InputIBtn.Click
        Try
            'update the output text with the letter returned by I being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("I", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputOBtn_Click(sender As Object, e As EventArgs) Handles InputOBtn.Click
        Try
            'update the output text with the letter returned by O being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("O", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputPBtn_Click(sender As Object, e As EventArgs) Handles InputPBtn.Click
        Try
            'update the output text with the letter returned by P being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("P", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputABtn_Click(sender As Object, e As EventArgs) Handles InputABtn.Click
        Try
            'update the output text with the letter returned by A being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("A", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputSBtn_Click(sender As Object, e As EventArgs) Handles InputSBtn.Click
        Try
            'update the output text with the letter returned by S being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("S", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputDBtn_Click(sender As Object, e As EventArgs) Handles InputDBtn.Click
        Try
            'update the output text with the letter returned by D being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("D", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputFBtn_Click(sender As Object, e As EventArgs) Handles InputFBtn.Click
        Try
            'update the output text with the letter returned by F being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("F", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputGBtn_Click(sender As Object, e As EventArgs) Handles InputGBtn.Click
        Try
            'update the output text with the letter returned by G being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("G", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputHBtn_Click(sender As Object, e As EventArgs) Handles InputHBtn.Click
        Try
            'update the output text with the letter returned by H being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("H", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputJBtn_Click(sender As Object, e As EventArgs) Handles InputJBtn.Click
        Try
            'update the output text with the letter returned by J being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("J", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputKBtn_Click(sender As Object, e As EventArgs) Handles InputKBtn.Click
        Try
            'update the output text with the letter returned by K being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("K", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputLBtn_Click(sender As Object, e As EventArgs) Handles InputLBtn.Click
        Try
            'update the output text with the letter returned by L being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("L", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputZBtn_Click(sender As Object, e As EventArgs) Handles InputZBtn.Click
        Try
            'update the output text with the letter returned by Z being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("Z", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputXBtn_Click(sender As Object, e As EventArgs) Handles InputXBtn.Click
        Try
            'update the output text with the letter returned by X being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("X", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputCBtn_Click(sender As Object, e As EventArgs) Handles InputCBtn.Click
        Try
            'update the output text with the letter returned by C being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("C", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputVBtn_Click(sender As Object, e As EventArgs) Handles InputVBtn.Click
        Try
            'update the output text with the letter returned by V being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("V", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputBBtn_Click(sender As Object, e As EventArgs) Handles InputBBtn.Click
        Try
            'update the output text with the letter returned by B being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("B", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputNBtn_Click(sender As Object, e As EventArgs) Handles InputNBtn.Click
        Try
            'update the output text with the letter returned by N being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("N", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub InputMBtn_Click(sender As Object, e As EventArgs) Handles InputMBtn.Click
        Try
            'update the output text with the letter returned by M being passed to the encryption algorithm
            OutputTextBox.Text = OutputTextBox.Text + Encryption("M", 1)
            Call UpdateRotors()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub PrinterBtn_Click(sender As Object, e As EventArgs) Handles PrinterBtn.Click
        Try
            'if the output text box is empty, give user an error message and exit the sub
            If OutputTextBox.Text = "" Then
                MsgBox("Transcript box is empty. Encrypt something first.")
                Exit Sub
            End If

            'create a dummy file with the output text
            FileOpen(1, "DummyFile.txt", OpenMode.Output)
            Write(1, OutputTextBox.Text)
            FileClose(1)

            'print the dummy file
            Dim proc As New Process
            proc.StartInfo.FileName = "DummyFile.txt"
            proc.StartInfo.Verb = "Print"
            proc.StartInfo.CreateNoWindow = True
            proc.Start()

            'allow the document to be printed before deleting it
            Threading.Thread.Sleep(640)

            'delete the dummy file
            My.Computer.FileSystem.DeleteFile("DummyFile.txt")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub
    Private Sub UpdateRotors()
        Try
            'declaration of variables
            Dim curr As Integer = 0
            Dim last As Integer = 0
            Dim nextChar As Integer = 0

            For i = 0 To 2
                'cycle through all the rotors ( 0 to 2 )
                'set the curr variable as equal to the current position of the given rotor, add 65 to translate it to an ASCII value. Then set the last and nextChar variables to curr -+ 1 respectively.
                curr = (Rotors.arrRotorPos(i) + 65)
                last = curr - 1
                nextChar = curr + 1

                If curr > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    curr = curr - 26
                ElseIf curr < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    curr = curr + 26
                End If

                If last > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    last = last - 26
                ElseIf last < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    last = last + 26
                End If

                If nextChar > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    nextChar = nextChar - 26
                ElseIf nextChar < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    nextChar = nextChar + 26
                End If

                If i = 0 Then
                    'if the current rotor is 0, set the rotor 1 position buttons to the respective values
                    Rotor1CurPos.Text = Chr(curr)
                    Rotor1LasPos.Text = Chr(last)
                    Rotor1NexPos.Text = Chr(nextChar)
                ElseIf i = 1 Then
                    'if the current rotor is 1, set the rotor 2 position buttons to the respective values
                    Rotor2CurPos.Text = Chr(curr)
                    Rotor2LasPos.Text = Chr(last)
                    Rotor2NexPos.Text = Chr(nextChar)
                Else
                    'if the current rotor is 2, set the rotor 3 position buttons to the respective values
                    Rotor3CurPos.Text = Chr(curr)
                    Rotor3LasPos.Text = Chr(last)
                    Rotor3NexPos.Text = Chr(nextChar)
                End If
            Next
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
        

    End Sub

    Private Sub EmailBtn_Click(sender As Object, e As EventArgs) Handles EmailBtn.Click
        Try
            'if no email address is set, return an error message and exit the sub
            If GlobalVariables.strEmailAddress = "null" Then
                MsgBox("Email services are unavailable. Enter an email on the 'Settings' Form.")
                Exit Sub
            End If

            'if the output text is empty return an error message and exit the sub
            If OutputTextBox.Text = "" Then
                MsgBox("Transcript box is empty. Encrypt something first.")
                Exit Sub
            End If

            'setting smtp server details
            Dim Smtp_Server As New SmtpClient
            Dim e_mail As New MailMessage()
            Smtp_Server.UseDefaultCredentials = False
            Smtp_Server.Credentials = New Net.NetworkCredential("encryptionprogram923465@gmail.com", "sdzfjopasfhdo") 'email function won't work, as the email address it used no longer exists'
            Smtp_Server.Port = 587
            Smtp_Server.EnableSsl = True
            Smtp_Server.Host = "smtp.gmail.com"

            'setting the body of the email then setting it
            e_mail = New MailMessage()
            e_mail.From = New MailAddress("encryptionprogram923465@gmail.com")
            e_mail.To.Add(GlobalVariables.strEmailAddress)
            e_mail.Subject = "Email Sending"
            e_mail.IsBodyHtml = False
            e_mail.Body = OutputTextBox.Text
            Smtp_Server.Send(e_mail)
            MsgBox("Mail Sent")

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub ExportBtn_Click(sender As Object, e As EventArgs) Handles ExportBtn.Click
        Try
            'if output text box is empty return an error message then exit the sub
            If OutputTextBox.Text = "" Then
                MsgBox("Output text is empty, nothing to output.")
                Exit Sub
            End If

            'opens file, or creates a new file if none exists, write output text to it then close the file
            FileOpen(1, GlobalVariables.strExportAddress, OpenMode.Output)
            PrintLine(1, OutputTextBox.Text)
            FileClose(1)

            'return a message to the user so that they know the button is actually doing something
            MsgBox("Output Exported to file selected in settings.")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub ImportBtn_Click(sender As Object, e As EventArgs) Handles ImportBtn.Click
        Try
            'declaration of variables
            Dim temp As String = ""
            Dim msgResponse As String

            'open import file, then copy contents into the 'temp' variable
            FileOpen(1, GlobalVariables.strImportAddress, OpenMode.Input)
            Input(1, temp)

            'clear output text box
            OutputTextBox.Text = ""

            'ask user whether inport file is to be encrypted or decrypted
            msgResponse = MsgBox("Decrypt input?", vbYesNo)
            If msgResponse = vbNo Then
                'if response is no encrypt the text from file. 
                For i = 1 To Len(temp)
                    'update the output text with the value returned from the encryption function when the current letter from the file is passed to it, then update the rotor display
                    OutputTextBox.Text = OutputTextBox.Text + Encryption((Mid(temp, i, 1)), 1)
                    Call UpdateRotors()
                Next
                MsgBox("Text from file encrypted.")
            Else
                MsgBox("Text will only decrypt correctly if the rotor wheels, rotor positions and plugboard connections are all the same as when the message was encrypted.")
                GlobalVariables.blnDecrypt = True
                'if response is yes decrypt the text from file. 
                For i = 1 To Len(temp)
                    'update the output text with the value returned from the encryption function when the current letter from the file is passed to it, then update the rotor display
                    OutputTextBox.Text = OutputTextBox.Text + Encryption((Mid(temp, i, 1)), 1)
                    Call UpdateRotors()
                Next
                GlobalVariables.blnDecrypt = False
                MsgBox("Text from file decrypted.")
            End If

            FileClose(1)
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub ClrOutBtn_Click(sender As Object, e As EventArgs) Handles ClrOutBtn.Click
        Try
            'clear output text and global output text
            OutputTextBox.Text = ""
            GlobalVariables.strOutputBox = OutputTextBox.Text

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub
End Class
