﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainInterface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainInterface))
        Me.RotLnkBtn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ExitBtn = New System.Windows.Forms.Button()
        Me.SetlnkBtn = New System.Windows.Forms.Button()
        Me.OutputTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Rotor3NexPos = New System.Windows.Forms.Label()
        Me.Rotor3LasPos = New System.Windows.Forms.Label()
        Me.Rotor3CurPos = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Rotor2CurPos = New System.Windows.Forms.Label()
        Me.Rotor2LasPos = New System.Windows.Forms.Label()
        Me.Rotor2NexPos = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Rotor1CurPos = New System.Windows.Forms.Label()
        Me.Rotor1LasPos = New System.Windows.Forms.Label()
        Me.Rotor1NexPos = New System.Windows.Forms.Label()
        Me.ImportBtn = New System.Windows.Forms.PictureBox()
        Me.PrinterBtn = New System.Windows.Forms.PictureBox()
        Me.ExportBtn = New System.Windows.Forms.PictureBox()
        Me.EmailBtn = New System.Windows.Forms.PictureBox()
        Me.HelpBtn = New System.Windows.Forms.PictureBox()
        Me.AnallnkBtn = New System.Windows.Forms.PictureBox()
        Me.InputQBtn = New System.Windows.Forms.Button()
        Me.InputWBtn = New System.Windows.Forms.Button()
        Me.InputEBtn = New System.Windows.Forms.Button()
        Me.InputRBtn = New System.Windows.Forms.Button()
        Me.InputTBtn = New System.Windows.Forms.Button()
        Me.InputYBtn = New System.Windows.Forms.Button()
        Me.InputUBtn = New System.Windows.Forms.Button()
        Me.InputIBtn = New System.Windows.Forms.Button()
        Me.InputOBtn = New System.Windows.Forms.Button()
        Me.InputKBtn = New System.Windows.Forms.Button()
        Me.InputJBtn = New System.Windows.Forms.Button()
        Me.InputHBtn = New System.Windows.Forms.Button()
        Me.InputGBtn = New System.Windows.Forms.Button()
        Me.InputFBtn = New System.Windows.Forms.Button()
        Me.InputDBtn = New System.Windows.Forms.Button()
        Me.InputSBtn = New System.Windows.Forms.Button()
        Me.InputABtn = New System.Windows.Forms.Button()
        Me.InputPBtn = New System.Windows.Forms.Button()
        Me.InputMBtn = New System.Windows.Forms.Button()
        Me.InputNBtn = New System.Windows.Forms.Button()
        Me.InputBBtn = New System.Windows.Forms.Button()
        Me.InputVBtn = New System.Windows.Forms.Button()
        Me.InputCBtn = New System.Windows.Forms.Button()
        Me.InputXBtn = New System.Windows.Forms.Button()
        Me.InputZBtn = New System.Windows.Forms.Button()
        Me.InputLBtn = New System.Windows.Forms.Button()
        Me.PlugLnkBtn = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ClrOutBtn = New System.Windows.Forms.Button()
        CType(Me.ImportBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PrinterBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ExportBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmailBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HelpBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AnallnkBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RotLnkBtn
        '
        Me.RotLnkBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RotLnkBtn.Location = New System.Drawing.Point(12, 12)
        Me.RotLnkBtn.Name = "RotLnkBtn"
        Me.RotLnkBtn.Size = New System.Drawing.Size(75, 25)
        Me.RotLnkBtn.TabIndex = 0
        Me.RotLnkBtn.Text = "Rotors"
        Me.RotLnkBtn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip1.SetToolTip(Me.RotLnkBtn, "Open rotors form.")
        Me.RotLnkBtn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(153, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(166, 26)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Main Interface"
        '
        'ExitBtn
        '
        Me.ExitBtn.Location = New System.Drawing.Point(596, 14)
        Me.ExitBtn.Name = "ExitBtn"
        Me.ExitBtn.Size = New System.Drawing.Size(75, 23)
        Me.ExitBtn.TabIndex = 2
        Me.ExitBtn.Text = "Exit"
        Me.ToolTip1.SetToolTip(Me.ExitBtn, "Exit the program.")
        Me.ExitBtn.UseVisualStyleBackColor = True
        '
        'SetlnkBtn
        '
        Me.SetlnkBtn.Location = New System.Drawing.Point(515, 14)
        Me.SetlnkBtn.Name = "SetlnkBtn"
        Me.SetlnkBtn.Size = New System.Drawing.Size(75, 23)
        Me.SetlnkBtn.TabIndex = 3
        Me.SetlnkBtn.Text = "Settings"
        Me.ToolTip1.SetToolTip(Me.SetlnkBtn, "Open settings form.")
        Me.SetlnkBtn.UseVisualStyleBackColor = True
        '
        'OutputTextBox
        '
        Me.OutputTextBox.BackColor = System.Drawing.Color.DarkGray
        Me.OutputTextBox.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OutputTextBox.Location = New System.Drawing.Point(465, 112)
        Me.OutputTextBox.Multiline = True
        Me.OutputTextBox.Name = "OutputTextBox"
        Me.OutputTextBox.ReadOnly = True
        Me.OutputTextBox.Size = New System.Drawing.Size(206, 260)
        Me.OutputTextBox.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.OutputTextBox, "Encrypted and decrypted text will appear here")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(461, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 19)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Output Text"
        '
        'Rotor3NexPos
        '
        Me.Rotor3NexPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor3NexPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor3NexPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor3NexPos.Location = New System.Drawing.Point(20, 132)
        Me.Rotor3NexPos.Name = "Rotor3NexPos"
        Me.Rotor3NexPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor3NexPos.TabIndex = 14
        Me.Rotor3NexPos.Text = "C"
        Me.Rotor3NexPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor3NexPos, "Rotor 1's next position")
        '
        'Rotor3LasPos
        '
        Me.Rotor3LasPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor3LasPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor3LasPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor3LasPos.Location = New System.Drawing.Point(20, 88)
        Me.Rotor3LasPos.Name = "Rotor3LasPos"
        Me.Rotor3LasPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor3LasPos.TabIndex = 15
        Me.Rotor3LasPos.Text = "A"
        Me.Rotor3LasPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor3LasPos, "Rotor 3's last position")
        '
        'Rotor3CurPos
        '
        Me.Rotor3CurPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor3CurPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor3CurPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor3CurPos.Location = New System.Drawing.Point(20, 110)
        Me.Rotor3CurPos.Name = "Rotor3CurPos"
        Me.Rotor3CurPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor3CurPos.TabIndex = 16
        Me.Rotor3CurPos.Text = "B"
        Me.Rotor3CurPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor3CurPos, "Rotor 3's current position")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(48, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 19)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "<--"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(115, 112)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 19)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "<--"
        '
        'Rotor2CurPos
        '
        Me.Rotor2CurPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor2CurPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor2CurPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor2CurPos.Location = New System.Drawing.Point(87, 109)
        Me.Rotor2CurPos.Name = "Rotor2CurPos"
        Me.Rotor2CurPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor2CurPos.TabIndex = 20
        Me.Rotor2CurPos.Text = "B"
        Me.Rotor2CurPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor2CurPos, "Rotor 2's current position")
        '
        'Rotor2LasPos
        '
        Me.Rotor2LasPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor2LasPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor2LasPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor2LasPos.Location = New System.Drawing.Point(87, 87)
        Me.Rotor2LasPos.Name = "Rotor2LasPos"
        Me.Rotor2LasPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor2LasPos.TabIndex = 19
        Me.Rotor2LasPos.Text = "A"
        Me.Rotor2LasPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor2LasPos, "Rotor 2's last position")
        '
        'Rotor2NexPos
        '
        Me.Rotor2NexPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor2NexPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor2NexPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor2NexPos.Location = New System.Drawing.Point(87, 131)
        Me.Rotor2NexPos.Name = "Rotor2NexPos"
        Me.Rotor2NexPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor2NexPos.TabIndex = 18
        Me.Rotor2NexPos.Text = "C"
        Me.Rotor2NexPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor2NexPos, "Rotor 1's next position")
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(183, 112)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(30, 19)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "<--"
        '
        'Rotor1CurPos
        '
        Me.Rotor1CurPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor1CurPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor1CurPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor1CurPos.Location = New System.Drawing.Point(155, 109)
        Me.Rotor1CurPos.Name = "Rotor1CurPos"
        Me.Rotor1CurPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor1CurPos.TabIndex = 24
        Me.Rotor1CurPos.Text = "B"
        Me.Rotor1CurPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor1CurPos, "Rotor 1's current position")
        '
        'Rotor1LasPos
        '
        Me.Rotor1LasPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor1LasPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor1LasPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor1LasPos.Location = New System.Drawing.Point(155, 87)
        Me.Rotor1LasPos.Name = "Rotor1LasPos"
        Me.Rotor1LasPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor1LasPos.TabIndex = 23
        Me.Rotor1LasPos.Text = "A"
        Me.Rotor1LasPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor1LasPos, "Rotor 1's last position")
        '
        'Rotor1NexPos
        '
        Me.Rotor1NexPos.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Rotor1NexPos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Rotor1NexPos.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rotor1NexPos.Location = New System.Drawing.Point(155, 131)
        Me.Rotor1NexPos.Name = "Rotor1NexPos"
        Me.Rotor1NexPos.Size = New System.Drawing.Size(22, 22)
        Me.Rotor1NexPos.TabIndex = 22
        Me.Rotor1NexPos.Text = "C"
        Me.Rotor1NexPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Rotor1NexPos, "Rotor 1's next position")
        '
        'ImportBtn
        '
        Me.ImportBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ImportBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ImportBtn.Image = CType(resources.GetObject("ImportBtn.Image"), System.Drawing.Image)
        Me.ImportBtn.Location = New System.Drawing.Point(571, 43)
        Me.ImportBtn.Name = "ImportBtn"
        Me.ImportBtn.Size = New System.Drawing.Size(47, 41)
        Me.ImportBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ImportBtn.TabIndex = 26
        Me.ImportBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.ImportBtn, "Import text from file.")
        '
        'PrinterBtn
        '
        Me.PrinterBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PrinterBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PrinterBtn.Image = CType(resources.GetObject("PrinterBtn.Image"), System.Drawing.Image)
        Me.PrinterBtn.Location = New System.Drawing.Point(465, 43)
        Me.PrinterBtn.Name = "PrinterBtn"
        Me.PrinterBtn.Size = New System.Drawing.Size(47, 41)
        Me.PrinterBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PrinterBtn.TabIndex = 27
        Me.PrinterBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PrinterBtn, "Print output text to printer.")
        '
        'ExportBtn
        '
        Me.ExportBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ExportBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ExportBtn.Image = CType(resources.GetObject("ExportBtn.Image"), System.Drawing.Image)
        Me.ExportBtn.Location = New System.Drawing.Point(624, 43)
        Me.ExportBtn.Name = "ExportBtn"
        Me.ExportBtn.Size = New System.Drawing.Size(47, 41)
        Me.ExportBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ExportBtn.TabIndex = 28
        Me.ExportBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.ExportBtn, "Export output text to file.")
        '
        'EmailBtn
        '
        Me.EmailBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.EmailBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.EmailBtn.Image = CType(resources.GetObject("EmailBtn.Image"), System.Drawing.Image)
        Me.EmailBtn.Location = New System.Drawing.Point(518, 43)
        Me.EmailBtn.Name = "EmailBtn"
        Me.EmailBtn.Size = New System.Drawing.Size(47, 41)
        Me.EmailBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.EmailBtn.TabIndex = 29
        Me.EmailBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.EmailBtn, "Email output text to a given address.")
        '
        'HelpBtn
        '
        Me.HelpBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.HelpBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.HelpBtn.Image = CType(resources.GetObject("HelpBtn.Image"), System.Drawing.Image)
        Me.HelpBtn.Location = New System.Drawing.Point(408, 12)
        Me.HelpBtn.Name = "HelpBtn"
        Me.HelpBtn.Size = New System.Drawing.Size(47, 41)
        Me.HelpBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HelpBtn.TabIndex = 30
        Me.HelpBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.HelpBtn, "Disable tooltips.")
        '
        'AnallnkBtn
        '
        Me.AnallnkBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.AnallnkBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.AnallnkBtn.Image = CType(resources.GetObject("AnallnkBtn.Image"), System.Drawing.Image)
        Me.AnallnkBtn.Location = New System.Drawing.Point(408, 68)
        Me.AnallnkBtn.Name = "AnallnkBtn"
        Me.AnallnkBtn.Size = New System.Drawing.Size(47, 41)
        Me.AnallnkBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.AnallnkBtn.TabIndex = 31
        Me.AnallnkBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.AnallnkBtn, "Open analytics form.")
        '
        'InputQBtn
        '
        Me.InputQBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputQBtn.Location = New System.Drawing.Point(37, 191)
        Me.InputQBtn.Name = "InputQBtn"
        Me.InputQBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputQBtn.TabIndex = 32
        Me.InputQBtn.Text = "Q"
        Me.InputQBtn.UseVisualStyleBackColor = True
        '
        'InputWBtn
        '
        Me.InputWBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputWBtn.Location = New System.Drawing.Point(78, 191)
        Me.InputWBtn.Name = "InputWBtn"
        Me.InputWBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputWBtn.TabIndex = 33
        Me.InputWBtn.Text = "W"
        Me.InputWBtn.UseVisualStyleBackColor = True
        '
        'InputEBtn
        '
        Me.InputEBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputEBtn.Location = New System.Drawing.Point(119, 191)
        Me.InputEBtn.Name = "InputEBtn"
        Me.InputEBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputEBtn.TabIndex = 34
        Me.InputEBtn.Text = "E"
        Me.InputEBtn.UseVisualStyleBackColor = True
        '
        'InputRBtn
        '
        Me.InputRBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputRBtn.Location = New System.Drawing.Point(160, 191)
        Me.InputRBtn.Name = "InputRBtn"
        Me.InputRBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputRBtn.TabIndex = 35
        Me.InputRBtn.Text = "R"
        Me.InputRBtn.UseVisualStyleBackColor = True
        '
        'InputTBtn
        '
        Me.InputTBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputTBtn.Location = New System.Drawing.Point(201, 191)
        Me.InputTBtn.Name = "InputTBtn"
        Me.InputTBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputTBtn.TabIndex = 36
        Me.InputTBtn.Text = "T"
        Me.InputTBtn.UseVisualStyleBackColor = True
        '
        'InputYBtn
        '
        Me.InputYBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputYBtn.Location = New System.Drawing.Point(242, 191)
        Me.InputYBtn.Name = "InputYBtn"
        Me.InputYBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputYBtn.TabIndex = 37
        Me.InputYBtn.Text = "Y"
        Me.InputYBtn.UseVisualStyleBackColor = True
        '
        'InputUBtn
        '
        Me.InputUBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputUBtn.Location = New System.Drawing.Point(283, 191)
        Me.InputUBtn.Name = "InputUBtn"
        Me.InputUBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputUBtn.TabIndex = 38
        Me.InputUBtn.Text = "U"
        Me.InputUBtn.UseVisualStyleBackColor = True
        '
        'InputIBtn
        '
        Me.InputIBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputIBtn.Location = New System.Drawing.Point(324, 191)
        Me.InputIBtn.Name = "InputIBtn"
        Me.InputIBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputIBtn.TabIndex = 39
        Me.InputIBtn.Text = "I"
        Me.InputIBtn.UseVisualStyleBackColor = True
        '
        'InputOBtn
        '
        Me.InputOBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputOBtn.Location = New System.Drawing.Point(365, 191)
        Me.InputOBtn.Name = "InputOBtn"
        Me.InputOBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputOBtn.TabIndex = 40
        Me.InputOBtn.Text = "O"
        Me.InputOBtn.UseVisualStyleBackColor = True
        '
        'InputKBtn
        '
        Me.InputKBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputKBtn.Location = New System.Drawing.Point(342, 232)
        Me.InputKBtn.Name = "InputKBtn"
        Me.InputKBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputKBtn.TabIndex = 49
        Me.InputKBtn.Text = "K"
        Me.InputKBtn.UseVisualStyleBackColor = True
        '
        'InputJBtn
        '
        Me.InputJBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputJBtn.Location = New System.Drawing.Point(301, 232)
        Me.InputJBtn.Name = "InputJBtn"
        Me.InputJBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputJBtn.TabIndex = 48
        Me.InputJBtn.Text = "J"
        Me.InputJBtn.UseVisualStyleBackColor = True
        '
        'InputHBtn
        '
        Me.InputHBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputHBtn.Location = New System.Drawing.Point(260, 232)
        Me.InputHBtn.Name = "InputHBtn"
        Me.InputHBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputHBtn.TabIndex = 47
        Me.InputHBtn.Text = "H"
        Me.InputHBtn.UseVisualStyleBackColor = True
        '
        'InputGBtn
        '
        Me.InputGBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputGBtn.Location = New System.Drawing.Point(219, 232)
        Me.InputGBtn.Name = "InputGBtn"
        Me.InputGBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputGBtn.TabIndex = 46
        Me.InputGBtn.Text = "G"
        Me.InputGBtn.UseVisualStyleBackColor = True
        '
        'InputFBtn
        '
        Me.InputFBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputFBtn.Location = New System.Drawing.Point(178, 232)
        Me.InputFBtn.Name = "InputFBtn"
        Me.InputFBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputFBtn.TabIndex = 45
        Me.InputFBtn.Text = "F"
        Me.InputFBtn.UseVisualStyleBackColor = True
        '
        'InputDBtn
        '
        Me.InputDBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputDBtn.Location = New System.Drawing.Point(137, 232)
        Me.InputDBtn.Name = "InputDBtn"
        Me.InputDBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputDBtn.TabIndex = 44
        Me.InputDBtn.Text = "D"
        Me.InputDBtn.UseVisualStyleBackColor = True
        '
        'InputSBtn
        '
        Me.InputSBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputSBtn.Location = New System.Drawing.Point(96, 232)
        Me.InputSBtn.Name = "InputSBtn"
        Me.InputSBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputSBtn.TabIndex = 43
        Me.InputSBtn.Text = "S"
        Me.InputSBtn.UseVisualStyleBackColor = True
        '
        'InputABtn
        '
        Me.InputABtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputABtn.Location = New System.Drawing.Point(55, 232)
        Me.InputABtn.Name = "InputABtn"
        Me.InputABtn.Size = New System.Drawing.Size(35, 35)
        Me.InputABtn.TabIndex = 42
        Me.InputABtn.Text = "A"
        Me.InputABtn.UseVisualStyleBackColor = True
        '
        'InputPBtn
        '
        Me.InputPBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputPBtn.Location = New System.Drawing.Point(406, 191)
        Me.InputPBtn.Name = "InputPBtn"
        Me.InputPBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputPBtn.TabIndex = 41
        Me.InputPBtn.Text = "P"
        Me.InputPBtn.UseVisualStyleBackColor = True
        '
        'InputMBtn
        '
        Me.InputMBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputMBtn.Location = New System.Drawing.Point(324, 273)
        Me.InputMBtn.Name = "InputMBtn"
        Me.InputMBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputMBtn.TabIndex = 57
        Me.InputMBtn.Text = "M"
        Me.InputMBtn.UseVisualStyleBackColor = True
        '
        'InputNBtn
        '
        Me.InputNBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputNBtn.Location = New System.Drawing.Point(283, 273)
        Me.InputNBtn.Name = "InputNBtn"
        Me.InputNBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputNBtn.TabIndex = 56
        Me.InputNBtn.Text = "N"
        Me.InputNBtn.UseVisualStyleBackColor = True
        '
        'InputBBtn
        '
        Me.InputBBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputBBtn.Location = New System.Drawing.Point(242, 273)
        Me.InputBBtn.Name = "InputBBtn"
        Me.InputBBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputBBtn.TabIndex = 55
        Me.InputBBtn.Text = "B"
        Me.InputBBtn.UseVisualStyleBackColor = True
        '
        'InputVBtn
        '
        Me.InputVBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputVBtn.Location = New System.Drawing.Point(201, 273)
        Me.InputVBtn.Name = "InputVBtn"
        Me.InputVBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputVBtn.TabIndex = 54
        Me.InputVBtn.Text = "V"
        Me.InputVBtn.UseVisualStyleBackColor = True
        '
        'InputCBtn
        '
        Me.InputCBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputCBtn.Location = New System.Drawing.Point(160, 273)
        Me.InputCBtn.Name = "InputCBtn"
        Me.InputCBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputCBtn.TabIndex = 53
        Me.InputCBtn.Text = "C"
        Me.InputCBtn.UseVisualStyleBackColor = True
        '
        'InputXBtn
        '
        Me.InputXBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputXBtn.Location = New System.Drawing.Point(119, 273)
        Me.InputXBtn.Name = "InputXBtn"
        Me.InputXBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputXBtn.TabIndex = 52
        Me.InputXBtn.Text = "X"
        Me.InputXBtn.UseVisualStyleBackColor = True
        '
        'InputZBtn
        '
        Me.InputZBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputZBtn.Location = New System.Drawing.Point(78, 273)
        Me.InputZBtn.Name = "InputZBtn"
        Me.InputZBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputZBtn.TabIndex = 51
        Me.InputZBtn.Text = "Z"
        Me.InputZBtn.UseVisualStyleBackColor = True
        '
        'InputLBtn
        '
        Me.InputLBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputLBtn.Location = New System.Drawing.Point(383, 232)
        Me.InputLBtn.Name = "InputLBtn"
        Me.InputLBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputLBtn.TabIndex = 50
        Me.InputLBtn.Text = "L"
        Me.InputLBtn.UseVisualStyleBackColor = True
        '
        'PlugLnkBtn
        '
        Me.PlugLnkBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlugLnkBtn.Location = New System.Drawing.Point(13, 332)
        Me.PlugLnkBtn.Name = "PlugLnkBtn"
        Me.PlugLnkBtn.Size = New System.Drawing.Size(132, 23)
        Me.PlugLnkBtn.TabIndex = 58
        Me.PlugLnkBtn.Text = "Plugboard Connections"
        Me.ToolTip1.SetToolTip(Me.PlugLnkBtn, "Open plugboard form.")
        Me.PlugLnkBtn.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 169)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(238, 15)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "Input text by clicking on the buttons below."
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(326, 18)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 30)
        Me.Label6.TabIndex = 60
        Me.Label6.Text = "Click here  ->" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " for help. "
        '
        'ClrOutBtn
        '
        Me.ClrOutBtn.Location = New System.Drawing.Point(596, 90)
        Me.ClrOutBtn.Name = "ClrOutBtn"
        Me.ClrOutBtn.Size = New System.Drawing.Size(75, 23)
        Me.ClrOutBtn.TabIndex = 61
        Me.ClrOutBtn.Text = "Clear Output"
        Me.ToolTip1.SetToolTip(Me.ClrOutBtn, "Exit the program.")
        Me.ClrOutBtn.UseVisualStyleBackColor = True
        '
        'MainInterface
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(683, 384)
        Me.ControlBox = False
        Me.Controls.Add(Me.ClrOutBtn)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PlugLnkBtn)
        Me.Controls.Add(Me.InputMBtn)
        Me.Controls.Add(Me.InputNBtn)
        Me.Controls.Add(Me.InputBBtn)
        Me.Controls.Add(Me.InputVBtn)
        Me.Controls.Add(Me.InputCBtn)
        Me.Controls.Add(Me.InputXBtn)
        Me.Controls.Add(Me.InputZBtn)
        Me.Controls.Add(Me.InputLBtn)
        Me.Controls.Add(Me.InputKBtn)
        Me.Controls.Add(Me.InputJBtn)
        Me.Controls.Add(Me.InputHBtn)
        Me.Controls.Add(Me.InputGBtn)
        Me.Controls.Add(Me.InputFBtn)
        Me.Controls.Add(Me.InputDBtn)
        Me.Controls.Add(Me.InputSBtn)
        Me.Controls.Add(Me.InputABtn)
        Me.Controls.Add(Me.InputPBtn)
        Me.Controls.Add(Me.InputOBtn)
        Me.Controls.Add(Me.InputIBtn)
        Me.Controls.Add(Me.InputUBtn)
        Me.Controls.Add(Me.InputYBtn)
        Me.Controls.Add(Me.InputTBtn)
        Me.Controls.Add(Me.InputRBtn)
        Me.Controls.Add(Me.InputEBtn)
        Me.Controls.Add(Me.InputWBtn)
        Me.Controls.Add(Me.InputQBtn)
        Me.Controls.Add(Me.AnallnkBtn)
        Me.Controls.Add(Me.HelpBtn)
        Me.Controls.Add(Me.EmailBtn)
        Me.Controls.Add(Me.ExportBtn)
        Me.Controls.Add(Me.PrinterBtn)
        Me.Controls.Add(Me.ImportBtn)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Rotor1CurPos)
        Me.Controls.Add(Me.Rotor1LasPos)
        Me.Controls.Add(Me.Rotor1NexPos)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Rotor2CurPos)
        Me.Controls.Add(Me.Rotor2LasPos)
        Me.Controls.Add(Me.Rotor2NexPos)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Rotor3CurPos)
        Me.Controls.Add(Me.Rotor3LasPos)
        Me.Controls.Add(Me.Rotor3NexPos)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.OutputTextBox)
        Me.Controls.Add(Me.SetlnkBtn)
        Me.Controls.Add(Me.ExitBtn)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RotLnkBtn)
        Me.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "MainInterface"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Interface"
        CType(Me.ImportBtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PrinterBtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ExportBtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmailBtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HelpBtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AnallnkBtn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents RotLnkBtn As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents ExitBtn As Button
    Friend WithEvents SetlnkBtn As Button
    Friend WithEvents OutputTextBox As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Rotor3NexPos As Label
    Friend WithEvents Rotor3LasPos As Label
    Friend WithEvents Rotor3CurPos As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Rotor2CurPos As Label
    Friend WithEvents Rotor2LasPos As Label
    Friend WithEvents Rotor2NexPos As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Rotor1CurPos As Label
    Friend WithEvents Rotor1LasPos As Label
    Friend WithEvents Rotor1NexPos As Label
    Friend WithEvents ImportBtn As PictureBox
    Friend WithEvents PrinterBtn As PictureBox
    Friend WithEvents ExportBtn As PictureBox
    Friend WithEvents EmailBtn As PictureBox
    Friend WithEvents HelpBtn As PictureBox
    Friend WithEvents AnallnkBtn As PictureBox
    Friend WithEvents InputQBtn As Button
    Friend WithEvents InputWBtn As Button
    Friend WithEvents InputEBtn As Button
    Friend WithEvents InputRBtn As Button
    Friend WithEvents InputTBtn As Button
    Friend WithEvents InputYBtn As Button
    Friend WithEvents InputUBtn As Button
    Friend WithEvents InputIBtn As Button
    Friend WithEvents InputOBtn As Button
	Friend WithEvents InputKBtn As Button
    Friend WithEvents InputJBtn As Button
    Friend WithEvents InputHBtn As Button
    Friend WithEvents InputGBtn As Button
    Friend WithEvents InputFBtn As Button
    Friend WithEvents InputDBtn As Button
    Friend WithEvents InputSBtn As Button
    Friend WithEvents InputABtn As Button
    Friend WithEvents InputPBtn As Button
    Friend WithEvents InputMBtn As Button
    Friend WithEvents InputNBtn As Button
    Friend WithEvents InputBBtn As Button
    Friend WithEvents InputVBtn As Button
    Friend WithEvents InputCBtn As Button
    Friend WithEvents InputXBtn As Button
    Friend WithEvents InputZBtn As Button
    Friend WithEvents InputLBtn As Button
    Friend WithEvents PlugLnkBtn As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ClrOutBtn As System.Windows.Forms.Button

End Class
