﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AnalysisInterface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AnalysisInterface))
        Me.TranscriptTxtBox = New System.Windows.Forms.TextBox()
        Me.MainLnkBtn = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PrinterBtn = New System.Windows.Forms.PictureBox()
        Me.HelpBtn = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ClrOutBtn = New System.Windows.Forms.Button()
        CType(Me.PrinterBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HelpBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TranscriptTxtBox
        '
        Me.TranscriptTxtBox.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.TranscriptTxtBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TranscriptTxtBox.Location = New System.Drawing.Point(12, 73)
        Me.TranscriptTxtBox.Multiline = True
        Me.TranscriptTxtBox.Name = "TranscriptTxtBox"
        Me.TranscriptTxtBox.ReadOnly = True
        Me.TranscriptTxtBox.Size = New System.Drawing.Size(504, 233)
        Me.TranscriptTxtBox.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.TranscriptTxtBox, "Transcript of encryption process")
        '
        'MainLnkBtn
        '
        Me.MainLnkBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainLnkBtn.Location = New System.Drawing.Point(12, 12)
        Me.MainLnkBtn.Name = "MainLnkBtn"
        Me.MainLnkBtn.Size = New System.Drawing.Size(75, 27)
        Me.MainLnkBtn.TabIndex = 2
        Me.MainLnkBtn.Text = "Main"
        Me.MainLnkBtn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip1.SetToolTip(Me.MainLnkBtn, "Return to main interface")
        Me.MainLnkBtn.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(110, 27)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(197, 26)
        Me.Label7.TabIndex = 42
        Me.Label7.Text = "Analysis Interface"
        '
        'PrinterBtn
        '
        Me.PrinterBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PrinterBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PrinterBtn.Image = CType(resources.GetObject("PrinterBtn.Image"), System.Drawing.Image)
        Me.PrinterBtn.Location = New System.Drawing.Point(469, 12)
        Me.PrinterBtn.Name = "PrinterBtn"
        Me.PrinterBtn.Size = New System.Drawing.Size(47, 41)
        Me.PrinterBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PrinterBtn.TabIndex = 43
        Me.PrinterBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PrinterBtn, "Print the contents of the transcript box")
        '
        'HelpBtn
        '
        Me.HelpBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.HelpBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.HelpBtn.Image = CType(resources.GetObject("HelpBtn.Image"), System.Drawing.Image)
        Me.HelpBtn.Location = New System.Drawing.Point(416, 12)
        Me.HelpBtn.Name = "HelpBtn"
        Me.HelpBtn.Size = New System.Drawing.Size(47, 41)
        Me.HelpBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HelpBtn.TabIndex = 44
        Me.HelpBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.HelpBtn, "Disable tooltips")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(339, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 28)
        Me.Label2.TabIndex = 45
        Me.Label2.Text = "Click here -->" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for help."
        '
        'ClrOutBtn
        '
        Me.ClrOutBtn.Location = New System.Drawing.Point(12, 45)
        Me.ClrOutBtn.Name = "ClrOutBtn"
        Me.ClrOutBtn.Size = New System.Drawing.Size(75, 23)
        Me.ClrOutBtn.TabIndex = 46
        Me.ClrOutBtn.Text = "Clear Output"
        Me.ClrOutBtn.UseVisualStyleBackColor = True
        '
        'AnalysisInterface
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(528, 318)
        Me.ControlBox = False
        Me.Controls.Add(Me.ClrOutBtn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.HelpBtn)
        Me.Controls.Add(Me.PrinterBtn)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.MainLnkBtn)
        Me.Controls.Add(Me.TranscriptTxtBox)
        Me.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "AnalysisInterface"
        Me.Text = "Analysis Interface"
        CType(Me.PrinterBtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HelpBtn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TranscriptTxtBox As TextBox
    Friend WithEvents MainLnkBtn As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents PrinterBtn As PictureBox
    Friend WithEvents HelpBtn As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ClrOutBtn As System.Windows.Forms.Button
End Class
