﻿Option Explicit On
Public Class AnalysisInterface

    Private Sub MainLnkBtn_Click(sender As Object, e As EventArgs) Handles MainLnkBtn.Click

        MainInterface.Show()
        Close()

    End Sub

    Private Sub AnalysisInterface_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            'fill out transcript box
            TranscriptTxtBox.Text = GlobalVariables.strAnalytics

            'turn tooltips on/off
            If GlobalVariables.blnHelpCheck = True Then
                ToolTip1.Active = True
                HelpBtn.Image = Image.FromFile("eye-icon-1464.png")
            Else
                ToolTip1.Active = False
                HelpBtn.Image = Image.FromFile("1200px-OOjs_UI_icon_eyeClosed.png")
            End If
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub HelpBtn_Click(sender As Object, e As EventArgs) Handles HelpBtn.Click
        Try
            'tooltips on or off
            If ToolTip1.Active = True Then
                ToolTip1.Active = False
                GlobalVariables.blnHelpCheck = False
                HelpBtn.Image = Image.FromFile("1200px-OOjs_UI_icon_eyeClosed.png")
            Else
                ToolTip1.Active = True
                GlobalVariables.blnHelpCheck = True
                HelpBtn.Image = Image.FromFile("eye-icon-1464.png")
            End If
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub PrinterBtn_Click(sender As Object, e As EventArgs) Handles PrinterBtn.Click
        Try
            'check if text box has anything to print
            If TranscriptTxtBox.Text = "" Then
                MsgBox("Transcript box is empty. Encrypt something first.")
                End
            End If

            'create a dummy file with the output text
            FileOpen(1, "DummyFile.txt", OpenMode.Output)
            Write(1, TranscriptTxtBox.Text)
            FileClose(1)

            'print the dummy file
            Dim proc As New Process
            proc.StartInfo.FileName = "DummyFile.txt"
            proc.StartInfo.Verb = "Print"
            proc.StartInfo.CreateNoWindow = True
            proc.Start()

            'allow the document to be printed before deleting it
            Threading.Thread.Sleep(640)

            'delete the dummy file
            My.Computer.FileSystem.DeleteFile("DummyFile.txt")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ClrOutBtn_Click(sender As Object, e As EventArgs) Handles ClrOutBtn.Click
        Try
            'clear analysis output
            TranscriptTxtBox.Text = ""
            GlobalVariables.strAnalytics = TranscriptTxtBox.Text
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub
End Class