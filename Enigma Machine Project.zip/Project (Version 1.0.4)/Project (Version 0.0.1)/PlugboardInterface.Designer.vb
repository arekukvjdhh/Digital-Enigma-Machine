﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PlugboardInterface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PlugboardInterface))
        Me.MainLnkBtn = New System.Windows.Forms.Button()
        Me.HelpBtn = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ConnectionsTxt = New System.Windows.Forms.TextBox()
        Me.SaveChangesBtn = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.InputMBtn = New System.Windows.Forms.Button()
        Me.InputNBtn = New System.Windows.Forms.Button()
        Me.InputBBtn = New System.Windows.Forms.Button()
        Me.InputVBtn = New System.Windows.Forms.Button()
        Me.InputCBtn = New System.Windows.Forms.Button()
        Me.InputXBtn = New System.Windows.Forms.Button()
        Me.InputZBtn = New System.Windows.Forms.Button()
        Me.InputLBtn = New System.Windows.Forms.Button()
        Me.InputKBtn = New System.Windows.Forms.Button()
        Me.InputJBtn = New System.Windows.Forms.Button()
        Me.InputHBtn = New System.Windows.Forms.Button()
        Me.InputGBtn = New System.Windows.Forms.Button()
        Me.InputFBtn = New System.Windows.Forms.Button()
        Me.InputDBtn = New System.Windows.Forms.Button()
        Me.InputSBtn = New System.Windows.Forms.Button()
        Me.InputABtn = New System.Windows.Forms.Button()
        Me.InputPBtn = New System.Windows.Forms.Button()
        Me.InputOBtn = New System.Windows.Forms.Button()
        Me.InputIBtn = New System.Windows.Forms.Button()
        Me.InputUBtn = New System.Windows.Forms.Button()
        Me.InputYBtn = New System.Windows.Forms.Button()
        Me.InputTBtn = New System.Windows.Forms.Button()
        Me.InputRBtn = New System.Windows.Forms.Button()
        Me.InputEBtn = New System.Windows.Forms.Button()
        Me.InputWBtn = New System.Windows.Forms.Button()
        Me.InputQBtn = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.HelpBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainLnkBtn
        '
        Me.MainLnkBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainLnkBtn.Location = New System.Drawing.Point(12, 12)
        Me.MainLnkBtn.Name = "MainLnkBtn"
        Me.MainLnkBtn.Size = New System.Drawing.Size(75, 27)
        Me.MainLnkBtn.TabIndex = 2
        Me.MainLnkBtn.Text = "Main"
        Me.MainLnkBtn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip1.SetToolTip(Me.MainLnkBtn, "Return to main interface")
        Me.MainLnkBtn.UseVisualStyleBackColor = True
        '
        'HelpBtn
        '
        Me.HelpBtn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.HelpBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.HelpBtn.Image = CType(resources.GetObject("HelpBtn.Image"), System.Drawing.Image)
        Me.HelpBtn.Location = New System.Drawing.Point(490, 12)
        Me.HelpBtn.Name = "HelpBtn"
        Me.HelpBtn.Size = New System.Drawing.Size(47, 44)
        Me.HelpBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HelpBtn.TabIndex = 34
        Me.HelpBtn.TabStop = False
        Me.ToolTip1.SetToolTip(Me.HelpBtn, "Disable tooltips")
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(149, 13)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(219, 26)
        Me.Label4.TabIndex = 40
        Me.Label4.Text = "Plugboard Interface"
        '
        'ConnectionsTxt
        '
        Me.ConnectionsTxt.Location = New System.Drawing.Point(130, 62)
        Me.ConnectionsTxt.Name = "ConnectionsTxt"
        Me.ConnectionsTxt.ReadOnly = True
        Me.ConnectionsTxt.Size = New System.Drawing.Size(279, 20)
        Me.ConnectionsTxt.TabIndex = 84
        Me.ToolTip1.SetToolTip(Me.ConnectionsTxt, "Current connections as text")
        '
        'SaveChangesBtn
        '
        Me.SaveChangesBtn.Location = New System.Drawing.Point(453, 318)
        Me.SaveChangesBtn.Name = "SaveChangesBtn"
        Me.SaveChangesBtn.Size = New System.Drawing.Size(84, 23)
        Me.SaveChangesBtn.TabIndex = 111
        Me.SaveChangesBtn.Text = "Save Changes"
        Me.ToolTip1.SetToolTip(Me.SaveChangesBtn, "Save changes to plugboard")
        Me.SaveChangesBtn.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(413, 17)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(71, 28)
        Me.Label27.TabIndex = 112
        Me.Label27.Text = "Click here -->" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for help."
        '
        'InputMBtn
        '
        Me.InputMBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputMBtn.Location = New System.Drawing.Point(359, 271)
        Me.InputMBtn.Name = "InputMBtn"
        Me.InputMBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputMBtn.TabIndex = 138
        Me.InputMBtn.Text = "M"
        Me.InputMBtn.UseVisualStyleBackColor = True
        '
        'InputNBtn
        '
        Me.InputNBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputNBtn.Location = New System.Drawing.Point(318, 271)
        Me.InputNBtn.Name = "InputNBtn"
        Me.InputNBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputNBtn.TabIndex = 137
        Me.InputNBtn.Text = "N"
        Me.InputNBtn.UseVisualStyleBackColor = True
        '
        'InputBBtn
        '
        Me.InputBBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputBBtn.Location = New System.Drawing.Point(277, 271)
        Me.InputBBtn.Name = "InputBBtn"
        Me.InputBBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputBBtn.TabIndex = 136
        Me.InputBBtn.Text = "B"
        Me.InputBBtn.UseVisualStyleBackColor = True
        '
        'InputVBtn
        '
        Me.InputVBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputVBtn.Location = New System.Drawing.Point(236, 271)
        Me.InputVBtn.Name = "InputVBtn"
        Me.InputVBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputVBtn.TabIndex = 135
        Me.InputVBtn.Text = "V"
        Me.InputVBtn.UseVisualStyleBackColor = True
        '
        'InputCBtn
        '
        Me.InputCBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputCBtn.Location = New System.Drawing.Point(195, 271)
        Me.InputCBtn.Name = "InputCBtn"
        Me.InputCBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputCBtn.TabIndex = 134
        Me.InputCBtn.Text = "C"
        Me.InputCBtn.UseVisualStyleBackColor = True
        '
        'InputXBtn
        '
        Me.InputXBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputXBtn.Location = New System.Drawing.Point(154, 271)
        Me.InputXBtn.Name = "InputXBtn"
        Me.InputXBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputXBtn.TabIndex = 133
        Me.InputXBtn.Text = "X"
        Me.InputXBtn.UseVisualStyleBackColor = True
        '
        'InputZBtn
        '
        Me.InputZBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputZBtn.Location = New System.Drawing.Point(113, 271)
        Me.InputZBtn.Name = "InputZBtn"
        Me.InputZBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputZBtn.TabIndex = 132
        Me.InputZBtn.Text = "Z"
        Me.InputZBtn.UseVisualStyleBackColor = True
        '
        'InputLBtn
        '
        Me.InputLBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputLBtn.Location = New System.Drawing.Point(418, 187)
        Me.InputLBtn.Name = "InputLBtn"
        Me.InputLBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputLBtn.TabIndex = 131
        Me.InputLBtn.Text = "L"
        Me.InputLBtn.UseVisualStyleBackColor = True
        '
        'InputKBtn
        '
        Me.InputKBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputKBtn.Location = New System.Drawing.Point(377, 187)
        Me.InputKBtn.Name = "InputKBtn"
        Me.InputKBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputKBtn.TabIndex = 130
        Me.InputKBtn.Text = "K"
        Me.InputKBtn.UseVisualStyleBackColor = True
        '
        'InputJBtn
        '
        Me.InputJBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputJBtn.Location = New System.Drawing.Point(336, 187)
        Me.InputJBtn.Name = "InputJBtn"
        Me.InputJBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputJBtn.TabIndex = 129
        Me.InputJBtn.Text = "J"
        Me.InputJBtn.UseVisualStyleBackColor = True
        '
        'InputHBtn
        '
        Me.InputHBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputHBtn.Location = New System.Drawing.Point(295, 187)
        Me.InputHBtn.Name = "InputHBtn"
        Me.InputHBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputHBtn.TabIndex = 128
        Me.InputHBtn.Text = "H"
        Me.InputHBtn.UseVisualStyleBackColor = True
        '
        'InputGBtn
        '
        Me.InputGBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputGBtn.Location = New System.Drawing.Point(254, 187)
        Me.InputGBtn.Name = "InputGBtn"
        Me.InputGBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputGBtn.TabIndex = 127
        Me.InputGBtn.Text = "G"
        Me.InputGBtn.UseVisualStyleBackColor = True
        '
        'InputFBtn
        '
        Me.InputFBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputFBtn.Location = New System.Drawing.Point(213, 187)
        Me.InputFBtn.Name = "InputFBtn"
        Me.InputFBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputFBtn.TabIndex = 126
        Me.InputFBtn.Text = "F"
        Me.InputFBtn.UseVisualStyleBackColor = True
        '
        'InputDBtn
        '
        Me.InputDBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputDBtn.Location = New System.Drawing.Point(172, 187)
        Me.InputDBtn.Name = "InputDBtn"
        Me.InputDBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputDBtn.TabIndex = 125
        Me.InputDBtn.Text = "D"
        Me.InputDBtn.UseVisualStyleBackColor = True
        '
        'InputSBtn
        '
        Me.InputSBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputSBtn.Location = New System.Drawing.Point(131, 187)
        Me.InputSBtn.Name = "InputSBtn"
        Me.InputSBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputSBtn.TabIndex = 124
        Me.InputSBtn.Text = "S"
        Me.InputSBtn.UseVisualStyleBackColor = True
        '
        'InputABtn
        '
        Me.InputABtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputABtn.Location = New System.Drawing.Point(90, 187)
        Me.InputABtn.Name = "InputABtn"
        Me.InputABtn.Size = New System.Drawing.Size(35, 35)
        Me.InputABtn.TabIndex = 123
        Me.InputABtn.Text = "A"
        Me.InputABtn.UseVisualStyleBackColor = True
        '
        'InputPBtn
        '
        Me.InputPBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputPBtn.Location = New System.Drawing.Point(441, 103)
        Me.InputPBtn.Name = "InputPBtn"
        Me.InputPBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputPBtn.TabIndex = 122
        Me.InputPBtn.Text = "P"
        Me.InputPBtn.UseVisualStyleBackColor = True
        '
        'InputOBtn
        '
        Me.InputOBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputOBtn.Location = New System.Drawing.Point(400, 103)
        Me.InputOBtn.Name = "InputOBtn"
        Me.InputOBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputOBtn.TabIndex = 121
        Me.InputOBtn.Text = "O"
        Me.InputOBtn.UseVisualStyleBackColor = True
        '
        'InputIBtn
        '
        Me.InputIBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputIBtn.Location = New System.Drawing.Point(359, 103)
        Me.InputIBtn.Name = "InputIBtn"
        Me.InputIBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputIBtn.TabIndex = 120
        Me.InputIBtn.Text = "I"
        Me.InputIBtn.UseVisualStyleBackColor = True
        '
        'InputUBtn
        '
        Me.InputUBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputUBtn.Location = New System.Drawing.Point(318, 103)
        Me.InputUBtn.Name = "InputUBtn"
        Me.InputUBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputUBtn.TabIndex = 119
        Me.InputUBtn.Text = "U"
        Me.InputUBtn.UseVisualStyleBackColor = True
        '
        'InputYBtn
        '
        Me.InputYBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputYBtn.Location = New System.Drawing.Point(277, 103)
        Me.InputYBtn.Name = "InputYBtn"
        Me.InputYBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputYBtn.TabIndex = 118
        Me.InputYBtn.Text = "Y"
        Me.InputYBtn.UseVisualStyleBackColor = True
        '
        'InputTBtn
        '
        Me.InputTBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputTBtn.Location = New System.Drawing.Point(236, 103)
        Me.InputTBtn.Name = "InputTBtn"
        Me.InputTBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputTBtn.TabIndex = 117
        Me.InputTBtn.Text = "T"
        Me.InputTBtn.UseVisualStyleBackColor = True
        '
        'InputRBtn
        '
        Me.InputRBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputRBtn.Location = New System.Drawing.Point(195, 103)
        Me.InputRBtn.Name = "InputRBtn"
        Me.InputRBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputRBtn.TabIndex = 116
        Me.InputRBtn.Text = "R"
        Me.InputRBtn.UseVisualStyleBackColor = True
        '
        'InputEBtn
        '
        Me.InputEBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputEBtn.Location = New System.Drawing.Point(154, 103)
        Me.InputEBtn.Name = "InputEBtn"
        Me.InputEBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputEBtn.TabIndex = 115
        Me.InputEBtn.Text = "E"
        Me.InputEBtn.UseVisualStyleBackColor = True
        '
        'InputWBtn
        '
        Me.InputWBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputWBtn.Location = New System.Drawing.Point(113, 103)
        Me.InputWBtn.Name = "InputWBtn"
        Me.InputWBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputWBtn.TabIndex = 114
        Me.InputWBtn.Text = "W"
        Me.InputWBtn.UseVisualStyleBackColor = True
        '
        'InputQBtn
        '
        Me.InputQBtn.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InputQBtn.Location = New System.Drawing.Point(72, 103)
        Me.InputQBtn.Name = "InputQBtn"
        Me.InputQBtn.Size = New System.Drawing.Size(35, 35)
        Me.InputQBtn.TabIndex = 113
        Me.InputQBtn.Text = "Q"
        Me.InputQBtn.UseVisualStyleBackColor = True
        '
        'PlugboardInterface
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(549, 353)
        Me.ControlBox = False
        Me.Controls.Add(Me.InputMBtn)
        Me.Controls.Add(Me.InputNBtn)
        Me.Controls.Add(Me.InputBBtn)
        Me.Controls.Add(Me.InputVBtn)
        Me.Controls.Add(Me.InputCBtn)
        Me.Controls.Add(Me.InputXBtn)
        Me.Controls.Add(Me.InputZBtn)
        Me.Controls.Add(Me.InputLBtn)
        Me.Controls.Add(Me.InputKBtn)
        Me.Controls.Add(Me.InputJBtn)
        Me.Controls.Add(Me.InputHBtn)
        Me.Controls.Add(Me.InputGBtn)
        Me.Controls.Add(Me.InputFBtn)
        Me.Controls.Add(Me.InputDBtn)
        Me.Controls.Add(Me.InputSBtn)
        Me.Controls.Add(Me.InputABtn)
        Me.Controls.Add(Me.InputPBtn)
        Me.Controls.Add(Me.InputOBtn)
        Me.Controls.Add(Me.InputIBtn)
        Me.Controls.Add(Me.InputUBtn)
        Me.Controls.Add(Me.InputYBtn)
        Me.Controls.Add(Me.InputTBtn)
        Me.Controls.Add(Me.InputRBtn)
        Me.Controls.Add(Me.InputEBtn)
        Me.Controls.Add(Me.InputWBtn)
        Me.Controls.Add(Me.InputQBtn)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.SaveChangesBtn)
        Me.Controls.Add(Me.ConnectionsTxt)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.HelpBtn)
        Me.Controls.Add(Me.MainLnkBtn)
        Me.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "PlugboardInterface"
        Me.Text = "Plugboard Interface"
        CType(Me.HelpBtn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MainLnkBtn As Button
    Friend WithEvents HelpBtn As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ConnectionsTxt As TextBox
    Friend WithEvents SaveChangesBtn As Button
    Friend WithEvents Label27 As Label
    Friend WithEvents InputMBtn As Button
    Friend WithEvents InputNBtn As Button
    Friend WithEvents InputBBtn As Button
    Friend WithEvents InputVBtn As Button
    Friend WithEvents InputCBtn As Button
    Friend WithEvents InputXBtn As Button
    Friend WithEvents InputZBtn As Button
    Friend WithEvents InputLBtn As Button
    Friend WithEvents InputKBtn As Button
    Friend WithEvents InputJBtn As Button
    Friend WithEvents InputHBtn As Button
    Friend WithEvents InputGBtn As Button
    Friend WithEvents InputFBtn As Button
    Friend WithEvents InputDBtn As Button
    Friend WithEvents InputSBtn As Button
    Friend WithEvents InputABtn As Button
    Friend WithEvents InputPBtn As Button
    Friend WithEvents InputOBtn As Button
    Friend WithEvents InputIBtn As Button
    Friend WithEvents InputUBtn As Button
    Friend WithEvents InputYBtn As Button
    Friend WithEvents InputTBtn As Button
    Friend WithEvents InputRBtn As Button
    Friend WithEvents InputEBtn As Button
    Friend WithEvents InputWBtn As Button
    Friend WithEvents InputQBtn As Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
