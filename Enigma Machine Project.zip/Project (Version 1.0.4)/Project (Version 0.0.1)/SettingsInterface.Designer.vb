﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SettingsInterface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MainLnkBtn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Emailtxt = New System.Windows.Forms.TextBox()
        Me.ImportTxt = New System.Windows.Forms.TextBox()
        Me.ExportTxt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Rotor3DefPos = New System.Windows.Forms.NumericUpDown()
        Me.Rotor1DefPos = New System.Windows.Forms.NumericUpDown()
        Me.Rotor2DefPos = New System.Windows.Forms.NumericUpDown()
        Me.PrintDialog = New System.Windows.Forms.PrintDialog()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ExportDirBtn = New System.Windows.Forms.Button()
        Me.ImportDirBtn = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        CType(Me.Rotor3DefPos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Rotor1DefPos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Rotor2DefPos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainLnkBtn
        '
        Me.MainLnkBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainLnkBtn.Location = New System.Drawing.Point(12, 12)
        Me.MainLnkBtn.Name = "MainLnkBtn"
        Me.MainLnkBtn.Size = New System.Drawing.Size(75, 27)
        Me.MainLnkBtn.TabIndex = 1
        Me.MainLnkBtn.Text = "Main"
        Me.MainLnkBtn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.MainLnkBtn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 21)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Email Address"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(13, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 21)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Export File"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(227, 121)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 21)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Import File"
        '
        'Emailtxt
        '
        Me.Emailtxt.Location = New System.Drawing.Point(17, 85)
        Me.Emailtxt.Name = "Emailtxt"
        Me.Emailtxt.Size = New System.Drawing.Size(132, 20)
        Me.Emailtxt.TabIndex = 2
        '
        'ImportTxt
        '
        Me.ImportTxt.Location = New System.Drawing.Point(231, 145)
        Me.ImportTxt.Name = "ImportTxt"
        Me.ImportTxt.Size = New System.Drawing.Size(132, 20)
        Me.ImportTxt.TabIndex = 4
        '
        'ExportTxt
        '
        Me.ExportTxt.Location = New System.Drawing.Point(17, 145)
        Me.ExportTxt.Name = "ExportTxt"
        Me.ExportTxt.Size = New System.Drawing.Size(132, 20)
        Me.ExportTxt.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(227, 60)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 21)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Rotor Defaults"
        '
        'Rotor3DefPos
        '
        Me.Rotor3DefPos.Location = New System.Drawing.Point(231, 85)
        Me.Rotor3DefPos.Maximum = New Decimal(New Integer() {26, 0, 0, 0})
        Me.Rotor3DefPos.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Rotor3DefPos.Name = "Rotor3DefPos"
        Me.Rotor3DefPos.Size = New System.Drawing.Size(35, 20)
        Me.Rotor3DefPos.TabIndex = 5
        Me.Rotor3DefPos.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Rotor1DefPos
        '
        Me.Rotor1DefPos.Location = New System.Drawing.Point(313, 86)
        Me.Rotor1DefPos.Maximum = New Decimal(New Integer() {26, 0, 0, 0})
        Me.Rotor1DefPos.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Rotor1DefPos.Name = "Rotor1DefPos"
        Me.Rotor1DefPos.Size = New System.Drawing.Size(35, 20)
        Me.Rotor1DefPos.TabIndex = 7
        Me.Rotor1DefPos.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Rotor2DefPos
        '
        Me.Rotor2DefPos.Location = New System.Drawing.Point(272, 86)
        Me.Rotor2DefPos.Maximum = New Decimal(New Integer() {26, 0, 0, 0})
        Me.Rotor2DefPos.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Rotor2DefPos.Name = "Rotor2DefPos"
        Me.Rotor2DefPos.Size = New System.Drawing.Size(35, 20)
        Me.Rotor2DefPos.TabIndex = 6
        Me.Rotor2DefPos.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'PrintDialog
        '
        Me.PrintDialog.UseEXDialog = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(95, 13)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(192, 26)
        Me.Label7.TabIndex = 41
        Me.Label7.Text = "Settings Interface"
        '
        'ExportDirBtn
        '
        Me.ExportDirBtn.Location = New System.Drawing.Point(150, 145)
        Me.ExportDirBtn.Name = "ExportDirBtn"
        Me.ExportDirBtn.Size = New System.Drawing.Size(21, 20)
        Me.ExportDirBtn.TabIndex = 42
        Me.ExportDirBtn.Text = ">"
        Me.ExportDirBtn.UseVisualStyleBackColor = True
        '
        'ImportDirBtn
        '
        Me.ImportDirBtn.Location = New System.Drawing.Point(364, 145)
        Me.ImportDirBtn.Name = "ImportDirBtn"
        Me.ImportDirBtn.Size = New System.Drawing.Size(21, 20)
        Me.ImportDirBtn.TabIndex = 43
        Me.ImportDirBtn.Text = ">"
        Me.ImportDirBtn.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'SettingsInterface
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(439, 229)
        Me.ControlBox = False
        Me.Controls.Add(Me.ImportDirBtn)
        Me.Controls.Add(Me.ExportDirBtn)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Rotor2DefPos)
        Me.Controls.Add(Me.Rotor1DefPos)
        Me.Controls.Add(Me.Rotor3DefPos)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ExportTxt)
        Me.Controls.Add(Me.ImportTxt)
        Me.Controls.Add(Me.Emailtxt)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MainLnkBtn)
        Me.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "SettingsInterface"
        Me.Text = "SettingsInterface"
        CType(Me.Rotor3DefPos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Rotor1DefPos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Rotor2DefPos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MainLnkBtn As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Emailtxt As TextBox
    Friend WithEvents ImportTxt As TextBox
    Friend WithEvents ExportTxt As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Rotor3DefPos As NumericUpDown
    Friend WithEvents Rotor1DefPos As NumericUpDown
    Friend WithEvents Rotor2DefPos As NumericUpDown
    Friend WithEvents PrintDialog As PrintDialog
    Friend WithEvents Label7 As Label
    Friend WithEvents ExportDirBtn As System.Windows.Forms.Button
    Friend WithEvents ImportDirBtn As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
End Class
