﻿Option Explicit On
Imports System.Text.RegularExpressions
Module GlobalCode

    Public Class GlobalVariables
        'Global variables declared 
        Public Shared strEmailAddress As String
        Public Shared strExportAddress As String
        Public Shared strImportAddress As String
        Public Shared strPrintAddress As String
        Public Shared blnPlugSave As Boolean
        Public Shared blnFirstLoad As Boolean = True
        Public Shared blnFormatCheck As Boolean
        Public Shared blnHelpCheck As Boolean
        Public Shared strPlugboard As String
        Public Shared strAnalytics As String '= ("Testing" & vbCrLf & "Testing") 'vbCrLf to increment new line in string
        Public Shared strOutputBox As String
        Public Shared blnDecrypt As Boolean
    End Class

    Public Class Rotors
        'Details for each Rotor
        Public Shared arrRotorWheelCyphers(5, 25) As Integer
        Public Shared arrRotorWheels(2) As Integer
        Public Shared arrRotorPos(2) As Integer
    End Class

    Public Sub LoadSettings()

        Try
            Dim strTemp As String = ""
            'Retrieve settings from file and update global variables with them

            'Retrieve settings file
            FileOpen(1, "SettingsFile.txt", OpenMode.Input)

            'Retrieve Default rotors, if its first load
            If GlobalVariables.blnFirstLoad = True Then
                GlobalVariables.blnHelpCheck = False
                Input(1, strTemp)

                Input(1, strTemp)
                Rotors.arrRotorPos(0) = CInt(strTemp)

                Input(1, strTemp)
                Rotors.arrRotorPos(1) = CInt(strTemp)

                Input(1, strTemp)
                Rotors.arrRotorPos(2) = CInt(strTemp)

                GlobalVariables.blnFirstLoad = False

                'Load rotor wheel cyphers, yes I realise this segment is bloated but it only has to run once
                '##Rewrite this as a loop when most of the important stuff is completed##
                'wheel cyph 1 of 6
                Rotors.arrRotorWheelCyphers(0, 0) = 4
                Rotors.arrRotorWheelCyphers(0, 1) = 9
                Rotors.arrRotorWheelCyphers(0, 2) = 10
                Rotors.arrRotorWheelCyphers(0, 3) = 2
                Rotors.arrRotorWheelCyphers(0, 4) = 7
                Rotors.arrRotorWheelCyphers(0, 5) = 1
                Rotors.arrRotorWheelCyphers(0, 6) = -3
                Rotors.arrRotorWheelCyphers(0, 7) = 9
                Rotors.arrRotorWheelCyphers(0, 8) = 13
                Rotors.arrRotorWheelCyphers(0, 9) = -10
                Rotors.arrRotorWheelCyphers(0, 10) = 3
                Rotors.arrRotorWheelCyphers(0, 11) = 8
                Rotors.arrRotorWheelCyphers(0, 12) = 2
                Rotors.arrRotorWheelCyphers(0, 13) = 9
                Rotors.arrRotorWheelCyphers(0, 14) = 10
                Rotors.arrRotorWheelCyphers(0, 15) = -8
                Rotors.arrRotorWheelCyphers(0, 16) = 7
                Rotors.arrRotorWheelCyphers(0, 17) = 3
                Rotors.arrRotorWheelCyphers(0, 18) = 0
                Rotors.arrRotorWheelCyphers(0, 19) = -4
                Rotors.arrRotorWheelCyphers(0, 20) = 6
                Rotors.arrRotorWheelCyphers(0, 21) = -13
                Rotors.arrRotorWheelCyphers(0, 22) = 5
                Rotors.arrRotorWheelCyphers(0, 23) = -6
                Rotors.arrRotorWheelCyphers(0, 24) = 4
                Rotors.arrRotorWheelCyphers(0, 25) = 10

                'wheel cyph 2 of 6
                Rotors.arrRotorWheelCyphers(1, 0) = 0
                Rotors.arrRotorWheelCyphers(1, 1) = 8
                Rotors.arrRotorWheelCyphers(1, 2) = 1
                Rotors.arrRotorWheelCyphers(1, 3) = 7
                Rotors.arrRotorWheelCyphers(1, 4) = -12
                Rotors.arrRotorWheelCyphers(1, 5) = 3
                Rotors.arrRotorWheelCyphers(1, 6) = 11
                Rotors.arrRotorWheelCyphers(1, 7) = 13
                Rotors.arrRotorWheelCyphers(1, 8) = -11
                Rotors.arrRotorWheelCyphers(1, 9) = -8
                Rotors.arrRotorWheelCyphers(1, 10) = 1
                Rotors.arrRotorWheelCyphers(1, 11) = -4
                Rotors.arrRotorWheelCyphers(1, 12) = 10
                Rotors.arrRotorWheelCyphers(1, 13) = 6
                Rotors.arrRotorWheelCyphers(1, 14) = -2
                Rotors.arrRotorWheelCyphers(1, 15) = -13
                Rotors.arrRotorWheelCyphers(1, 16) = 0
                Rotors.arrRotorWheelCyphers(1, 17) = -11
                Rotors.arrRotorWheelCyphers(1, 18) = 7
                Rotors.arrRotorWheelCyphers(1, 19) = -6
                Rotors.arrRotorWheelCyphers(1, 20) = -5
                Rotors.arrRotorWheelCyphers(1, 21) = 3
                Rotors.arrRotorWheelCyphers(1, 22) = 9
                Rotors.arrRotorWheelCyphers(1, 23) = -2
                Rotors.arrRotorWheelCyphers(1, 24) = -10
                Rotors.arrRotorWheelCyphers(1, 25) = 5

                'wheel cyph 3 of 6
                Rotors.arrRotorWheelCyphers(2, 0) = 1
                Rotors.arrRotorWheelCyphers(2, 1) = 3
                Rotors.arrRotorWheelCyphers(2, 2) = 3
                Rotors.arrRotorWheelCyphers(2, 3) = 4
                Rotors.arrRotorWheelCyphers(2, 4) = 5
                Rotors.arrRotorWheelCyphers(2, 5) = 6
                Rotors.arrRotorWheelCyphers(2, 6) = -4
                Rotors.arrRotorWheelCyphers(2, 7) = 8
                Rotors.arrRotorWheelCyphers(2, 8) = 9
                Rotors.arrRotorWheelCyphers(2, 9) = 10
                Rotors.arrRotorWheelCyphers(2, 10) = 13
                Rotors.arrRotorWheelCyphers(2, 11) = 10
                Rotors.arrRotorWheelCyphers(2, 12) = 13
                Rotors.arrRotorWheelCyphers(2, 13) = 0
                Rotors.arrRotorWheelCyphers(2, 14) = 10
                Rotors.arrRotorWheelCyphers(2, 15) = -11
                Rotors.arrRotorWheelCyphers(2, 16) = -8
                Rotors.arrRotorWheelCyphers(2, 17) = 5
                Rotors.arrRotorWheelCyphers(2, 18) = -12
                Rotors.arrRotorWheelCyphers(2, 19) = 7
                Rotors.arrRotorWheelCyphers(2, 20) = -10
                Rotors.arrRotorWheelCyphers(2, 21) = -9
                Rotors.arrRotorWheelCyphers(2, 22) = -2
                Rotors.arrRotorWheelCyphers(2, 23) = -5
                Rotors.arrRotorWheelCyphers(2, 24) = -8
                Rotors.arrRotorWheelCyphers(2, 25) = -11

                'wheel cyph 4 of 6
                Rotors.arrRotorWheelCyphers(3, 0) = 4
                Rotors.arrRotorWheelCyphers(3, 1) = -9
                Rotors.arrRotorWheelCyphers(3, 2) = 12
                Rotors.arrRotorWheelCyphers(3, 3) = -8
                Rotors.arrRotorWheelCyphers(3, 4) = 11
                Rotors.arrRotorWheelCyphers(3, 5) = -6
                Rotors.arrRotorWheelCyphers(3, 6) = 3
                Rotors.arrRotorWheelCyphers(3, 7) = -7
                Rotors.arrRotorWheelCyphers(3, 8) = -10
                Rotors.arrRotorWheelCyphers(3, 9) = 7
                Rotors.arrRotorWheelCyphers(3, 10) = 10
                Rotors.arrRotorWheelCyphers(3, 11) = -3
                Rotors.arrRotorWheelCyphers(3, 12) = 5
                Rotors.arrRotorWheelCyphers(3, 13) = -6
                Rotors.arrRotorWheelCyphers(3, 14) = 9
                Rotors.arrRotorWheelCyphers(3, 15) = -4
                Rotors.arrRotorWheelCyphers(3, 16) = -3
                Rotors.arrRotorWheelCyphers(3, 17) = -12
                Rotors.arrRotorWheelCyphers(3, 18) = 1
                Rotors.arrRotorWheelCyphers(3, 19) = -13
                Rotors.arrRotorWheelCyphers(3, 20) = -10
                Rotors.arrRotorWheelCyphers(3, 21) = 8
                Rotors.arrRotorWheelCyphers(3, 22) = 6
                Rotors.arrRotorWheelCyphers(3, 23) = -11
                Rotors.arrRotorWheelCyphers(3, 24) = -2
                Rotors.arrRotorWheelCyphers(3, 25) = 2

                'wheel cyph 5 of 6
                Rotors.arrRotorWheelCyphers(4, 0) = -5
                Rotors.arrRotorWheelCyphers(4, 1) = -2
                Rotors.arrRotorWheelCyphers(4, 2) = -1
                Rotors.arrRotorWheelCyphers(4, 3) = -12
                Rotors.arrRotorWheelCyphers(4, 4) = 2
                Rotors.arrRotorWheelCyphers(4, 5) = 3
                Rotors.arrRotorWheelCyphers(4, 6) = 13
                Rotors.arrRotorWheelCyphers(4, 7) = -9
                Rotors.arrRotorWheelCyphers(4, 8) = 12
                Rotors.arrRotorWheelCyphers(4, 9) = 6
                Rotors.arrRotorWheelCyphers(4, 10) = 8
                Rotors.arrRotorWheelCyphers(4, 11) = -8
                Rotors.arrRotorWheelCyphers(4, 12) = 1
                Rotors.arrRotorWheelCyphers(4, 13) = -6
                Rotors.arrRotorWheelCyphers(4, 14) = -3
                Rotors.arrRotorWheelCyphers(4, 15) = 8
                Rotors.arrRotorWheelCyphers(4, 16) = 10
                Rotors.arrRotorWheelCyphers(4, 17) = 5
                Rotors.arrRotorWheelCyphers(4, 18) = -6
                Rotors.arrRotorWheelCyphers(4, 19) = -10
                Rotors.arrRotorWheelCyphers(4, 20) = -4
                Rotors.arrRotorWheelCyphers(4, 21) = -7
                Rotors.arrRotorWheelCyphers(4, 22) = 9
                Rotors.arrRotorWheelCyphers(4, 23) = 7
                Rotors.arrRotorWheelCyphers(4, 24) = 4
                Rotors.arrRotorWheelCyphers(4, 25) = 11

                'wheel cyph 6 of 6
                Rotors.arrRotorWheelCyphers(5, 0) = 5
                Rotors.arrRotorWheelCyphers(5, 1) = -6
                Rotors.arrRotorWheelCyphers(5, 2) = 13
                Rotors.arrRotorWheelCyphers(5, 3) = 6
                Rotors.arrRotorWheelCyphers(5, 4) = 4
                Rotors.arrRotorWheelCyphers(5, 5) = -5
                Rotors.arrRotorWheelCyphers(5, 6) = 8
                Rotors.arrRotorWheelCyphers(5, 7) = -9
                Rotors.arrRotorWheelCyphers(5, 8) = -4
                Rotors.arrRotorWheelCyphers(5, 9) = -6
                Rotors.arrRotorWheelCyphers(5, 10) = 7
                Rotors.arrRotorWheelCyphers(5, 11) = -12
                Rotors.arrRotorWheelCyphers(5, 12) = 11
                Rotors.arrRotorWheelCyphers(5, 13) = 9
                Rotors.arrRotorWheelCyphers(5, 14) = -8
                Rotors.arrRotorWheelCyphers(5, 15) = -13
                Rotors.arrRotorWheelCyphers(5, 16) = 3
                Rotors.arrRotorWheelCyphers(5, 17) = -7
                Rotors.arrRotorWheelCyphers(5, 18) = 2
                Rotors.arrRotorWheelCyphers(5, 19) = -3
                Rotors.arrRotorWheelCyphers(5, 20) = -2
                Rotors.arrRotorWheelCyphers(5, 21) = 6
                Rotors.arrRotorWheelCyphers(5, 22) = -9
                Rotors.arrRotorWheelCyphers(5, 23) = -11
                Rotors.arrRotorWheelCyphers(5, 24) = 9
                Rotors.arrRotorWheelCyphers(5, 25) = 12

                Rotors.arrRotorWheels(0) = 0
                Rotors.arrRotorWheels(1) = 1
                Rotors.arrRotorWheels(2) = 2

            Else
                'If not first load, leave rotors as they are
                Input(1, strTemp)
                Input(1, strTemp)
                Input(1, strTemp)
                Input(1, strTemp)
            End If

            'Retrieve email address
            Input(1, strTemp)
            Input(1, GlobalVariables.strEmailAddress)

            'Retrieve export address
            Input(1, strTemp)
            Input(1, GlobalVariables.strExportAddress)

            'Retrieve import address
            Input(1, strTemp)
            Input(1, GlobalVariables.strImportAddress)

            'close settings file
            FileClose(1)

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try

    End Sub

    Public Sub ValidateEmailFormat(ByVal email As String)
        Try
            'Validate format of email then update blnFormatCheck as true or false
            If Regex.IsMatch(email, "^[_a-z0-9-]+(.[a-z0-9-]+)@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$") Then
                GlobalVariables.blnFormatCheck = True
            Else
                GlobalVariables.blnFormatCheck = False
            End If
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Public Function Encryption(ByVal Character As Char, ByVal Rotor As Integer)
        Try
            Dim intValidation As Integer = 0
            Dim intEncrypt As Integer = 0
            Dim chrTemp As Char = ""
            Dim blnfound As Boolean = False
            'validates that input character is a letter, not a symbol or otherwise
            intValidation = Asc(Character)
            If (intValidation < 65 Or intValidation > 90) And (intValidation < 97 Or intValidation > 122) Then
                MsgBox("Invalid character encountered. Ensure input does not include symbols.")
                Return Character
            End If

            Character = UCase(Character)

            If Rotor = 1 Then
                'Check if Character is in the plugboard
                For i = 1 To Len(GlobalVariables.strPlugboard)
                    If blnfound = False Then
                        If Character = Mid(GlobalVariables.strPlugboard, i, 1) Then
                            'Check if Plugboard Position is odd or even
                            If i Mod 2 <> 0 Or i = 1 Then
                                'set character as it's connected chracter in plugboard
                                Character = Mid(GlobalVariables.strPlugboard, i + 1, 1)
                                blnfound = True
                                'updates analytics variable
                                GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Plugboard encrypts " & (Chr(intValidation)) & " into " & Character & vbCrLf)
                            Else
                                'set character as it's connected chracter in plugboard
                                Character = Mid(GlobalVariables.strPlugboard, i - 1, 1)
                                blnfound = True
                                'updates analytics variable
                                GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Plugboard encrypts " & (Chr(intValidation)) & " into " & Character & vbCrLf)
                            End If
                        End If
                    End If
                Next

            ElseIf Rotor = 4 Then
                'converts character to Ascii
                intEncrypt = Asc(Character)

                'temporary storage for analytics variable
                chrTemp = Character

                intEncrypt = intEncrypt + Rotors.arrRotorWheelCyphers(5, (intEncrypt - 65))
                If intEncrypt > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    intEncrypt = intEncrypt - 26
                ElseIf intEncrypt < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    intEncrypt = intEncrypt + 26
                End If
                'converts ascii back into character
                Character = Chr(intEncrypt)

                'updates analytics variable
                GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Rotor " & Rotor & " encrypts " & chrTemp & " into " & Character & vbCrLf)

                Return Character

            End If

            'converts character to Ascii
            intEncrypt = Asc(Character)

            'temporary storage for analytics variable
            chrTemp = Character

            'edits ascii value by amount specified in current rotor's cypher.
            If GlobalVariables.blnDecrypt = False Then
                intEncrypt = intEncrypt + Rotors.arrRotorWheelCyphers((Rotors.arrRotorWheels(Rotor - 1)), Rotors.arrRotorPos(Rotor - 1))
            Else
                intEncrypt = intEncrypt - Rotors.arrRotorWheelCyphers((Rotors.arrRotorWheels(Rotor - 1)), Rotors.arrRotorPos(Rotor - 1))
            End If

            If intEncrypt > 90 Then
                'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet 
                intEncrypt = intEncrypt - 26
            ElseIf intEncrypt < 65 Then
                'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet 
                intEncrypt = intEncrypt + 26
            End If

            'converts ascii back into character
            Character = Chr(intEncrypt)

            'updates analytics variable
            GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Rotor " & Rotor & " encrypts " & chrTemp & " into " & Character & vbCrLf)

            'If Rotor = 1 Then
            '    'if the current rotor is 1, rotate rotor 1 by 1 place
            '    Call RotateRotors()
            'End If

            'send character back through function with next rotor
            Character = Encryption(Character, (Rotor + 1))

            'converts character to Ascii
            intEncrypt = Asc(Character)

            'temporary storage for analytics variable
            chrTemp = Character

            'edits ascii value by amount specified in current rotor's cypher.
            If GlobalVariables.blnDecrypt = False Then
                intEncrypt = intEncrypt + Rotors.arrRotorWheelCyphers((Rotors.arrRotorWheels(Rotor - 1)), Rotors.arrRotorPos(Rotor - 1))
            Else
                intEncrypt = intEncrypt - Rotors.arrRotorWheelCyphers((Rotors.arrRotorWheels(Rotor - 1)), Rotors.arrRotorPos(Rotor - 1))
            End If

            If intEncrypt > 90 Then
                'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet 
                intEncrypt = intEncrypt - 26
            ElseIf intEncrypt < 65 Then
                'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet 
                intEncrypt = intEncrypt + 26
            End If
            'converts ascii back into character
            Character = Chr(intEncrypt)

            'updates analytics variable
            GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Rotor " & Rotor & " encrypts " & chrTemp & " into " & Character & vbCrLf)


            If Rotor = 1 Then
                blnfound = False
                'Check if Character is in the plugboard
                For i = 1 To Len(GlobalVariables.strPlugboard)
                    If blnfound = False Then
                        If Character = Mid(GlobalVariables.strPlugboard, i, 1) Then
                            'Check if Plugboard Position is odd or even
                            If i Mod 2 <> 0 Or i = 1 Then
                                'set character as it's connected chracter in plugboard
                                Character = Mid(GlobalVariables.strPlugboard, i + 1, 1)
                                blnfound = True
                                'updates analytics variable
                                GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Plugboard encrypts " & (Chr(intEncrypt)) & " into " & Character & vbCrLf)
                            Else
                                'set character as it's connected chracter in plugboard
                                Character = Mid(GlobalVariables.strPlugboard, i - 1, 1)
                                blnfound = True
                                'updates analytics variable
                                GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Plugboard encrypts " & (Chr(intEncrypt)) & " into " & Character & vbCrLf)
                            End If
                        End If
                    End If
                Next
            End If

            If Rotor = 1 Then
                'if the current rotor is 1, rotate rotor 1 by 1 place
                Call RotateRotors()
            End If

            Return Character
        Catch ex As Exception
            MsgBox(Err.Description)
            Return Character
        End Try
    End Function

    Public Sub RotateRotors()
        Try
            'Increment Rotor 1 by 1
            Rotors.arrRotorPos(0) = Rotors.arrRotorPos(0) + 1

            'updates analytics variable
            GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Rotor 1 increments" & vbCrLf)

            If Rotors.arrRotorPos(0) = 26 Then
                'If rotor 1 now = 26, reset rotor 1 to 0 and increment rotor 2 by 1
                Rotors.arrRotorPos(0) = 0
                Rotors.arrRotorPos(1) = Rotors.arrRotorPos(1) + 1

                'updates analytics variable
                GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Rotor 2 increments" & vbCrLf)

                If Rotors.arrRotorPos(1) = 26 Then
                    'If rotor 2 now = 26, reset rotor 2 to 0 and increment rotor 3 by 1
                    Rotors.arrRotorPos(1) = 0
                    Rotors.arrRotorPos(2) = Rotors.arrRotorPos(2) + 1

                    'updates analytics variable
                    GlobalVariables.strAnalytics = GlobalVariables.strAnalytics + ("Rotor 3 increments" & vbCrLf)

                    If Rotors.arrRotorPos(2) = 26 Then
                        'If rotor 3 now = 26, reset rotor 3 to 0
                        Rotors.arrRotorPos(2) = 0
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub
End Module
