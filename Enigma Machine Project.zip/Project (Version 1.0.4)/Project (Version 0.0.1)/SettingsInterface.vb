﻿Option Explicit On
Public Class SettingsInterface

    Private Sub MainLnkBtn_Click(sender As Object, e As EventArgs) Handles MainLnkBtn.Click
        Try
            'Opens Settings file
            FileOpen(1, "SettingsFile.txt", OpenMode.Output)

            'rotor positions saved
            Write(1, "rotorDefault")
            Write(1, (Rotor3DefPos.Value - 1))
            Write(1, (Rotor2DefPos.Value - 1))
            Write(1, (Rotor1DefPos.Value - 1))

            'email address validated and saved
            ValidateEmailFormat(Emailtxt.Text)
            Write(1, "emailAddress")
            If Emailtxt.Text = "" Then
                MsgBox("Email address is blank, email features will be unavailable")
                Write(1, "null")
            ElseIf GlobalVariables.blnFormatCheck = True Then
                Write(1, Emailtxt.Text)
            Else
                MsgBox("Incorrect Email format, email features will be unavailable")
                Write(1, "null")
            End If

            'export file address
            Write(1, "exportAddress")
            If ExportTxt.Text = "" Then
                MsgBox("Export address is blank, export features will be unavailable")
                Write(1, "null")
            Else
                Write(1, ExportTxt.Text)
            End If

            'import file address
            Write(1, "importAddress")
            If ImportTxt.Text = "" Then
                MsgBox("Import address is blank, import features will be unavailable")
                Write(1, "null")
            Else
                Write(1, ImportTxt.Text)
            End If

            FileClose(1)


            MainInterface.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
        
    End Sub

    Private Sub ExportDirBtn_Click(sender As Object, e As EventArgs) Handles ExportDirBtn.Click
        Try
            MsgBox("Please select a notepad file to output encrypted or decrypted text to.")
            'open save file dialog to get the user to select a file to output to

            OpenFileDialog1.ShowDialog()

            ExportTxt.Text = OpenFileDialog1.FileName

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub ImportDirBtn_Click(sender As Object, e As EventArgs) Handles ImportDirBtn.Click
        Try
            MsgBox("Please select a notepad file containing the text you wish encrypted or decrypted.")
            'open save file dialog to get the user to select a file to input from

            OpenFileDialog1.ShowDialog()

            ImportTxt.Text = OpenFileDialog1.FileName
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub


    Private Sub SettingsInterface_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Emailtxt.Text = GlobalVariables.strEmailAddress
        ImportTxt.Text = GlobalVariables.strImportAddress
        ExportTxt.Text = GlobalVariables.strExportAddress
    End Sub
End Class