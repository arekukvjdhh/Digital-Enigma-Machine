﻿Option Explicit On
Public Class RotorInterface
    Dim arrRotorPos(2) As Integer


    Private Sub MainLnkBtn_Click(sender As Object, e As EventArgs) Handles MainLnkBtn.Click

        MainInterface.Show()
        Close()

    End Sub

    Private Sub HelpBtn_Click(sender As Object, e As EventArgs) Handles HelpBtn.Click
        Try
            'tooltips on or off
            If ToolTip1.Active = True Then
                ToolTip1.Active = False
                GlobalVariables.blnHelpCheck = False
                HelpBtn.Image = Image.FromFile("1200px-OOjs_UI_icon_eyeClosed.png")
            Else
                ToolTip1.Active = True
                GlobalVariables.blnHelpCheck = True
                HelpBtn.Image = Image.FromFile("eye-icon-1464.png")
            End If
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub RotorInterface_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            'turn tooltips on/off
            If GlobalVariables.blnHelpCheck = True Then
                ToolTip1.Active = True
                HelpBtn.Image = Image.FromFile("eye-icon-1464.png")
            Else
                ToolTip1.Active = False
                HelpBtn.Image = Image.FromFile("1200px-OOjs_UI_icon_eyeClosed.png")
            End If

            'sets the selector boxes as the currently selected wheel cyphers
            Rotor1DskComBox.SelectedIndex = CInt(Rotors.arrRotorWheels(0))
            Rotor2DskComBox.SelectedIndex = CInt(Rotors.arrRotorWheels(1))
            Rotor3DskComBox.SelectedIndex = CInt(Rotors.arrRotorWheels(2))

            Call UpdateRotors()
            arrRotorPos(0) = Rotors.arrRotorPos(0) + 1
            arrRotorPos(1) = Rotors.arrRotorPos(1) + 1
            arrRotorPos(2) = Rotors.arrRotorPos(2) + 1

        Catch ex As Exception

        End Try

    End Sub

    Private Sub UpdateRotors()
        Try
            Dim curr As Integer = 0
            Dim last As Integer = 0
            Dim nextChar As Integer = 0

            For i = 0 To 2
                curr = (Rotors.arrRotorPos(i) + 65)
                last = curr - 1
                nextChar = curr + 1
                If curr > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    curr = curr - 26
                ElseIf curr < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    curr = curr + 26
                End If

                If last > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    last = last - 26
                ElseIf last < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    last = last + 26
                End If

                If nextChar > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    nextChar = nextChar - 26
                ElseIf nextChar < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    nextChar = nextChar + 26
                End If

                If i = 0 Then
                    Rotor1CurPos.Text = Chr(curr)
                    Rotor1LasPos.Text = Chr(last)
                    Rotor1NexPos.Text = Chr(nextChar)
                ElseIf i = 1 Then
                    Rotor2CurPos.Text = Chr(curr)
                    Rotor2LasPos.Text = Chr(last)
                    Rotor2NexPos.Text = Chr(nextChar)
                Else
                    Rotor3CurPos.Text = Chr(curr)
                    Rotor3LasPos.Text = Chr(last)
                    Rotor3NexPos.Text = Chr(nextChar)
                End If
            Next
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub SaveChangesBtn_Click(sender As Object, e As EventArgs) Handles SaveChangesBtn.Click
        Try

            If Rotor1DskComBox.SelectedIndex > 4 Or Rotor1DskComBox.SelectedIndex < 0 Or Rotor2DskComBox.SelectedIndex > 4 Or Rotor2DskComBox.SelectedIndex < 0 Or Rotor3DskComBox.SelectedIndex > 4 Or Rotor3DskComBox.SelectedIndex < 0 Then
                MsgBox("Rotor wheels outside expected bounds.")
                Exit Sub
            End If
            'update global rotor wheels
            Rotors.arrRotorWheels(0) = CInt(Rotor1DskComBox.SelectedIndex)
            Rotors.arrRotorWheels(1) = CInt(Rotor2DskComBox.SelectedIndex)
            Rotors.arrRotorWheels(2) = CInt(Rotor3DskComBox.SelectedIndex)

            'update global rotor positions
            Rotors.arrRotorPos(0) = arrRotorPos(0) - 1
            Rotors.arrRotorPos(1) = arrRotorPos(1) - 1
            Rotors.arrRotorPos(2) = arrRotorPos(2) - 1

            MsgBox("Rotor positions and wheels saved.")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub Rotor1LasPos_Click(sender As Object, e As EventArgs) Handles Rotor1LasPos.Click
        Try
            'decrease rotor 1's position 
            arrRotorPos(0) = arrRotorPos(0) - 1
            Call UpdateDisplay()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub Rotor2LasPos_Click(sender As Object, e As EventArgs) Handles Rotor2LasPos.Click
        Try
            'decrease rotor 2's position 
            arrRotorPos(1) = arrRotorPos(1) - 1
            Call UpdateDisplay()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub Rotor3LasPos_Click(sender As Object, e As EventArgs) Handles Rotor3LasPos.Click
        Try
            'decrease rotor 3's position 
            arrRotorPos(2) = arrRotorPos(2) - 1
            Call UpdateDisplay()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub Rotor1NexPos_Click(sender As Object, e As EventArgs) Handles Rotor1NexPos.Click
        Try
            'increase rotor 1's position 
            arrRotorPos(0) = arrRotorPos(0) + 1
            Call UpdateDisplay()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub Rotor2NexPos_Click(sender As Object, e As EventArgs) Handles Rotor2NexPos.Click
        Try
            'increase rotor 2's position 
            arrRotorPos(1) = arrRotorPos(1) + 1
            Call UpdateDisplay()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub Rotor3NexPos_Click(sender As Object, e As EventArgs) Handles Rotor3NexPos.Click
        Try
            'increase rotor 3's position 
            arrRotorPos(2) = arrRotorPos(2) + 1
            Call UpdateDisplay()
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub UpdateDisplay()
        Try
            Dim curr As Integer = 0
            Dim last As Integer = 0
            Dim nextChar As Integer = 0

            For i = 0 To 2
                curr = (arrRotorPos(i) + 64)
                last = curr - 1
                nextChar = curr + 1
                If curr > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    curr = curr - 26
                ElseIf curr < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    curr = curr + 26
                End If

                If last > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    last = last - 26
                ElseIf last < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    last = last + 26
                End If

                If nextChar > 90 Then
                    'if the resultant ascii value is greater than the ascii value of 'Z', loops back to start of uppercase alphabet
                    nextChar = nextChar - 26
                ElseIf nextChar < 65 Then
                    'if the resultant ascii value is less than the ascii value of 'A', loops back to top of uppercase alphabet
                    nextChar = nextChar + 26
                End If

                If i = 0 Then
                    Rotor1CurPos.Text = Chr(curr)
                    Rotor1LasPos.Text = Chr(last)
                    Rotor1NexPos.Text = Chr(nextChar)
                ElseIf i = 1 Then
                    Rotor2CurPos.Text = Chr(curr)
                    Rotor2LasPos.Text = Chr(last)
                    Rotor2NexPos.Text = Chr(nextChar)
                Else
                    Rotor3CurPos.Text = Chr(curr)
                    Rotor3LasPos.Text = Chr(last)
                    Rotor3NexPos.Text = Chr(nextChar)
                End If
            Next
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

End Class